package com.example.discovery.ibfsn.Adapter;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.discovery.ibfsn.Activites.Activity_Family;
import com.example.discovery.ibfsn.Objects.Family;
import com.example.discovery.ibfsn.Others.Main;
import com.example.discovery.ibfsn.R;
import com.squareup.picasso.Picasso;

import java.util.Date;
import java.util.List;

import de.hdodenhof.circleimageview.CircleImageView;

/**
 * Created by Discovery on 19/04/2018.
 */

public class AdapterListFamilies extends ArrayAdapter<Family> {


    private Activity context;
    private List<Family> LST;



    public AdapterListFamilies(Activity context, List<Family> LST) {
        super(context, R.layout.item_family, LST);

        this.context = context;
        this.LST = LST;


    }

    public View getView(final int position, final View convertView, ViewGroup parent) {

        LayoutInflater layoutInflater = context.getLayoutInflater();
        final View viewItem = layoutInflater.inflate(R.layout.item_family, null, true);

       ((TextView)viewItem.findViewById(R.id.textViewNameFamily)).setText(LST.get(position).getName());
       ((TextView)viewItem.findViewById(R.id.textViewNumberMemberOfFamily)).setText(Main.getInstance().mGetNumberOfMembers(LST.get(position).getId())+ " Memebers");

        Date d = new Date(LST.get(position).getDate());
        ((TextView)viewItem.findViewById(R.id.textViewDateCreateFamily)).setText(d.toString());

        if (LST.get(position).getLinkPhoto() == null) {
            ((CircleImageView)viewItem.findViewById(R.id.imageViewPhotoFamily)).setImageResource(R.mipmap.logo_family);
        } else{
            Picasso.get().load(LST.get(position).getLinkPhoto()).into((CircleImageView)viewItem.findViewById(R.id.imageViewPhotoFamily));
        }

        viewItem.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Activity_Family.idFamily = LST.get(position).getId();
                Intent intent = new Intent(context , Activity_Family.class);
                context.startActivity(intent);
            }
        });

        ((CircleImageView)viewItem.findViewById(R.id.imageViewPhotoFamily)).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                AlertDialog.Builder dialogBuilder = new AlertDialog.Builder(context);
                final ImageView imageViewPhoto = new ImageView(context);

                Picasso.get().load(LST.get(position).getLinkPhoto()).into(imageViewPhoto);
                dialogBuilder.setView(imageViewPhoto);

                AlertDialog alertDialog = dialogBuilder.create();
                alertDialog.show();
            }
        });


        return  viewItem;
    }

}
