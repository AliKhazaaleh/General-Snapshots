package com.example.discovery.ibfsn.Json;

import com.example.discovery.ibfsn.Objects.Like;

/**
 * Created by Discovery on 18/04/2018.
 */

public class JsonLike {

    public String id;
    public String idUser;
    public String idPostOrComment;
    public long date;

    public Like ConvertToObject(){
        Like like = new Like( id,  idUser,  idPostOrComment,  date);
        return like;
    }
}
