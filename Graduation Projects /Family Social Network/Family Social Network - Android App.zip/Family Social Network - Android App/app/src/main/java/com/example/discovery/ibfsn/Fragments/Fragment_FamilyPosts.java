package com.example.discovery.ibfsn.Fragments;


import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.design.widget.FloatingActionButton;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.support.v4.app.Fragment;
import android.widget.ListView;

import com.example.discovery.ibfsn.Activites.Activity_CreatePost;
import com.example.discovery.ibfsn.Json.JsonPost;
import com.example.discovery.ibfsn.Objects.Post;
import com.example.discovery.ibfsn.Others.AppRefDB;
import com.example.discovery.ibfsn.Others.Main;
import com.example.discovery.ibfsn.R;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.ValueEventListener;

/**
 * Created by Discovery on 26/04/2018.
 */

public class Fragment_FamilyPosts extends Fragment {

    View rootView;
    ListView listViewPosts;
    FloatingActionButton floatingActionButtonAddPost;


    public static Fragment_FamilyPosts newInstance() {
        Fragment_FamilyPosts fragment = new Fragment_FamilyPosts();
        return fragment;
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, Bundle savedInstanceState) {

        rootView = inflater.inflate(R.layout.fragment_family_posts, container, false);
        mLoadObjects();
        mLoadUI();
        mLoadActions();
        Main.getInstance().mLoadListViewPosts(getActivity() ,listViewPosts );
        return  rootView;
    }

    private void mLoadObjects() {
        mOpenConection();
    }

    private void mOpenConection() {

    }

    private void mLoadUI() {

       listViewPosts = (ListView)rootView.findViewById(R.id.listViewPosts);
       floatingActionButtonAddPost = (FloatingActionButton)rootView.findViewById(R.id.floatingActionButtonAddPost);
    }

    private void mLoadActions() {
        floatingActionButtonAddPost.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent intent = new Intent(getActivity(), Activity_CreatePost.class);
                startActivity(intent);
            }
        });
    }


    @Override
    public void onStart() {
        super.onStart();


        AppRefDB.RefPosts.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                Main.getInstance().getMAPpost().clear();
                for (DataSnapshot dataSnapshot_post : dataSnapshot.getChildren()){
                    Post post = dataSnapshot_post.getValue(JsonPost.class).ConvertToObject();
                    Main.getInstance().getMAPpost().put(post.getId() , post );
                }

                Main.getInstance().mLoadListViewPosts(getActivity() ,listViewPosts );
            }
            @Override
            public void onCancelled(DatabaseError databaseError) {
            }
        });


    }

}
