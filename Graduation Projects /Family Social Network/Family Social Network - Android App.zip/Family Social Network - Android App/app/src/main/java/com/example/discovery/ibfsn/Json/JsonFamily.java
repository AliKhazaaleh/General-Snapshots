package com.example.discovery.ibfsn.Json;

import com.example.discovery.ibfsn.Objects.Family;

/**
 * Created by Discovery on 18/04/2018.
 */

public class JsonFamily {

    public String id;
    public String name;
    public String lunch;
    public String linkPhoto;
    public long date;

    public Family ConvertToObject(){
        Family family = new Family( id,  name,  lunch, linkPhoto,  date);
        return family;
    }

}
