package com.example.discovery.ibfsn.Adapter;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.discovery.ibfsn.Activites.Activity_Comments;
import com.example.discovery.ibfsn.Activites.Activity_MapPost;
import com.example.discovery.ibfsn.Objects.Comment;
import com.example.discovery.ibfsn.Objects.Like;
import com.example.discovery.ibfsn.Objects.Post;
import com.example.discovery.ibfsn.Others.AppSettings;
import com.example.discovery.ibfsn.Others.Main;
import com.example.discovery.ibfsn.R;
import com.squareup.picasso.Picasso;

import java.util.Date;
import java.util.List;
import java.util.Map;

import de.hdodenhof.circleimageview.CircleImageView;

/**
 * Created by Discovery on 30/04/2018.
 */

public class AdapterListPosts extends ArrayAdapter<Post> {

    private Activity context;
    private List<Post> LST;

    public AdapterListPosts(Activity context, List<Post> LST) {
        super(context, R.layout.item_post, LST);

        this.context = context;
        this.LST = LST;
    }

    public View getView(final int position, final View convertView, ViewGroup parent) {

        LayoutInflater layoutInflater = context.getLayoutInflater();
        final View viewItem = layoutInflater.inflate(R.layout.item_post, null, true);


        // for Photo Post
        if (  LST.get(position).getLinkPhoto() == null || LST.get(position).getLinkPhoto() == "" ) {
            ((ImageView)viewItem.findViewById(R.id.imageViewPhotoPost)).setVisibility(View.GONE);
        } else{
            Picasso.get().load(LST.get(position).getLinkPhoto()).into((ImageView)viewItem.findViewById(R.id.imageViewPhotoPost));
        }


        // prees on photo post
        ((ImageView)viewItem.findViewById(R.id.imageViewPhotoPost)).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                AlertDialog.Builder dialogBuilder = new AlertDialog.Builder(context);
                final ImageView imageViewPhoto = new ImageView(context);

                Picasso.get().load( LST.get(position).getLinkPhoto()).into(imageViewPhoto);
                dialogBuilder.setView(imageViewPhoto);

                AlertDialog alertDialog = dialogBuilder.create();
                alertDialog.show();
            }
        });

        // for photo user
        if ( Main.getInstance().getMAPuser().get( LST.get(position).getIdUser()).getLinkPhoto() == null) {
            ((CircleImageView)viewItem.findViewById(R.id.circleImageViewPhotoMember)).setImageResource(R.mipmap.logo_member);
        } else{
            Picasso.get().load(Main.getInstance().getMAPuser().get( LST.get(position).getIdUser()).getLinkPhoto()).into((CircleImageView)viewItem.findViewById(R.id.circleImageViewPhotoMember));
        }

        // prees on photo user
        ((ImageView)viewItem.findViewById(R.id.circleImageViewPhotoMember)).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                AlertDialog.Builder dialogBuilder = new AlertDialog.Builder(context);
                final ImageView imageViewPhoto = new ImageView(context);

                Picasso.get().load( Main.getInstance().getMAPuser().get(LST.get(position).getIdUser()).getLinkPhoto()).into(imageViewPhoto);
                dialogBuilder.setView(imageViewPhoto);

                AlertDialog alertDialog = dialogBuilder.create();
                alertDialog.show();
            }
        });

        if (LST.get(position).getText() == null || LST.get(position).getText().equals(""))
            ((TextView)viewItem.findViewById(R.id.textViewTextOfPost)).setVisibility(View.GONE);
        else
            ((TextView)viewItem.findViewById(R.id.textViewTextOfPost)).setText(LST.get(position).getText());

        ((TextView)viewItem.findViewById(R.id.textViewMemberName)).setText( "Posted By " + Main.getInstance().getMAPuser().get(LST.get(position).getIdUser()).getName());
        Date d = new Date(LST.get(position).getDate());
        ((TextView)viewItem.findViewById(R.id.textViewDatePost)).setText(d.toString());

        if ( LST.get(position).getLocLat() == 0 ){
            ((ImageView)viewItem.findViewById(R.id.imageViewLocationPost)).setEnabled(false);
        } else {
            ((ImageView)viewItem.findViewById(R.id.imageViewLocationPost)).setImageResource(R.mipmap.logo_location_post_active);
        }

        ((ImageView)viewItem.findViewById(R.id.imageViewLocationPost)).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent( context , Activity_MapPost.class);
                intent.putExtra("lat" ,  LST.get(position).getLocLat() );
                intent.putExtra("lon" ,  LST.get(position).getLocLon() );
                context.startActivity(intent);
            }
        });

        // +++++++++++++++++++++
        ((ImageView)viewItem.findViewById(R.id.commentsCountImageView)).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent( context , Activity_Comments.class);
                Activity_Comments.post = LST.get(position);
                context.startActivity(intent);
            }
        });

        ((TextView)viewItem.findViewById(R.id.textViewTextOfPost)).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent( context , Activity_Comments.class);
                Activity_Comments.post = LST.get(position);
                context.startActivity(intent);
            }
        });

        ((TextView)viewItem.findViewById(R.id.textViewCommentsCount)).setText(Main.getInstance().getLSTcomment(LST.get(position).getId()).size()+"");
        ((TextView)viewItem.findViewById(R.id.textViewLikeCounter)).setText(Main.getInstance().getLSTlike(LST.get(position).getId()).size()+"");

        if (Main.getInstance().mCheckAddLike(Main.user.getId() , LST.get(position).getId()) ) {
            ((ImageView)viewItem.findViewById(R.id.likesImageView)).setImageResource(R.mipmap.logo_like_active);
        }
        else {
            ((ImageView)viewItem.findViewById(R.id.likesImageView)).setImageResource(R.mipmap.logo_like);
        }


        ((ImageView)viewItem.findViewById(R.id.likesImageView)).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if (!AppSettings.mIsNetworkAvailable(context , view))
                    return;

                if (Main.getInstance().mCheckAddLike(Main.user.getId() , LST.get(position).getId())){
                    ((ImageView)viewItem.findViewById(R.id.likesImageView)).setImageResource(R.mipmap.logo_like);
                     Main.user.mRemoveLike(LST.get(position).getId());
                    ((TextView)viewItem.findViewById(R.id.textViewLikeCounter)).setText( (Integer.parseInt((((TextView) viewItem.findViewById(R.id.textViewLikeCounter)).getText().toString()) ) -1 )+"");

                } else
                {
                    ((ImageView)viewItem.findViewById(R.id.likesImageView)).setImageResource(R.mipmap.logo_like_active);
                     Main.user.mAddLike(LST.get(position).getId());

                     if ( !  ((((TextView) viewItem.findViewById(R.id.textViewLikeCounter)).getText().toString()) == null) )
                    ((TextView)viewItem.findViewById(R.id.textViewLikeCounter)).setText( (Integer.parseInt((((TextView) viewItem.findViewById(R.id.textViewLikeCounter)).getText().toString()) ) +1 )+"");
                }

            }
        });


        if (!LST.get(position).getIdUser().equals(Main.user.getId()))
            ((Button)viewItem.findViewById(R.id.buttonDeletePost)).setVisibility(View.GONE);


        ((Button)viewItem.findViewById(R.id.buttonDeletePost)).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Main.getInstance().mDeletePost(LST.get(position).getId());
            }
        });

        return viewItem;
    }

}
