package com.example.discovery.ibfsn.Json;

import com.example.discovery.ibfsn.Objects.Location;

/**
 * Created by Discovery on 18/04/2018.
 */

public class JsonLocation {

    public String id;
    public String idUser;
    public double locLat;
    public double locLon;
    public long date;

    public Location ConvertToObject(){
        Location location = new Location( id,  idUser,  locLat, locLon, date);
        return location;
    }
}
