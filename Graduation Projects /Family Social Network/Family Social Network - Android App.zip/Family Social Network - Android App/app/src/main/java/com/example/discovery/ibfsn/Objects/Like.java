package com.example.discovery.ibfsn.Objects;


import com.example.discovery.ibfsn.Others.AppSettings;
import com.example.discovery.ibfsn.Others.Main;


public class Like {

    private String id;
    private String idUser;
    private String idPostOrComment;
    private long date;

    public Like() {}

    public Like(String id, String idUser, String idPostOrComment) {
        this.id = id;
        this.idUser = idUser;
        this.idPostOrComment = idPostOrComment;
        this.date =  AppSettings.CurrentTimeMillis();
    }

    public Like(String id, String idUser, String idPostOrComment, long date) {
        this.id = id;
        this.idUser = idUser;
        this.idPostOrComment = idPostOrComment;
        this.date = date;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getIdUser() {
        return idUser;
    }

    public void setIdUser(String idUser) {
        this.idUser = idUser;
    }

    public String getIdPostOrComment() {
        return idPostOrComment;
    }

    public void setIdPostOrComment(String idPostOrComment) {
        this.idPostOrComment = idPostOrComment;
    }

    public long getDate() {
        return date;
    }

    public void setDate(long date) {
        this.date = date;
    }

/*
    public User getUser(){
        return Main.getInstance().getMAPuser().get(idUser);
    }
*/
}
