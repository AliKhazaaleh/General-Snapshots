package com.example.discovery.ibfsn.Activites;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import com.example.discovery.ibfsn.Json.JsonComment;
import com.example.discovery.ibfsn.Objects.Comment;
import com.example.discovery.ibfsn.Objects.Post;
import com.example.discovery.ibfsn.Others.AppRefDB;
import com.example.discovery.ibfsn.Others.AppSettings;
import com.example.discovery.ibfsn.Others.Main;
import com.example.discovery.ibfsn.R;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.ValueEventListener;

import es.dmoral.toasty.Toasty;

public class Activity_Comments extends AppCompatActivity {


    public static Post post;
    Button buttonSend;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_comments);

        mLoadObjects();
        mLoadUI();
        mLoadActions();
    }

    private void mLoadObjects() {

    }

    private void mLoadUI() {

        //(EditText)findViewById(R.id.editTextComment);
        buttonSend = (Button)findViewById(R.id.buttonSend);
        Main.getInstance().mLoadListViewComments(Activity_Comments.this , (ListView)findViewById(R.id.listViewComments));

    }

    private void mLoadActions() {

        buttonSend.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if ( !mCheckComment(((EditText)findViewById(R.id.editTextComment)).getText().toString() )){
                    Toasty.warning( getBaseContext(), "Not Can Add empty comment", Toast.LENGTH_SHORT, true).show();
                    return;
                }

                if (!AppSettings.mIsNetworkAvailable(Activity_Comments.this , view))
                    return;

                Main.user.mAddCooment( ((EditText)findViewById(R.id.editTextComment)).getText().toString() );
                Toasty.success( getBaseContext(), "Added", Toast.LENGTH_SHORT, true).show();
                ((EditText)findViewById(R.id.editTextComment)).setText("");
                Main.getInstance().mLoadListViewComments(Activity_Comments.this , (ListView)findViewById(R.id.listViewComments));
            }
        });
    }


    @Override
    protected void onStart() {
        super.onStart();


        AppRefDB.RefComments.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {

                Main.getInstance().getMAPcomment().clear();
                for (DataSnapshot dataSnapshot_comment : dataSnapshot.getChildren()){
                    Comment comment = dataSnapshot_comment.getValue(JsonComment.class).ConvertToObject();
                    Main.getInstance().getMAPcomment().put(comment.getId() , comment );
                }
                Main.getInstance().mLoadListViewComments(Activity_Comments.this , (ListView)findViewById(R.id.listViewComments));

            }
            @Override
            public void onCancelled(DatabaseError databaseError) {
            }
        });
    }

    private boolean mCheckComment(String comment) {

        if (comment.equals(""))
            return false;

        boolean flag=false;

        for (char ch : comment.toCharArray())
            if (ch == ' ')
                continue;
        else
            flag =true;

        return flag;
    }
}
