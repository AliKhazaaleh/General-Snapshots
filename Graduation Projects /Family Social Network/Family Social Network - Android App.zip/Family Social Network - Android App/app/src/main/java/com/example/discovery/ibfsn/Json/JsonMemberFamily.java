package com.example.discovery.ibfsn.Json;

import com.example.discovery.ibfsn.Objects.MemberFamily;

/**
 * Created by Discovery on 18/04/2018.
 */

public class JsonMemberFamily {

    public String id;
    public String idUser;
    public String idFamily;
    public String adjective;
    public long date;

    public MemberFamily ConvertToObject(){
        MemberFamily memberFamily = new MemberFamily( id,  idUser,  idFamily,adjective ,  date);
        return memberFamily;
    }

}
