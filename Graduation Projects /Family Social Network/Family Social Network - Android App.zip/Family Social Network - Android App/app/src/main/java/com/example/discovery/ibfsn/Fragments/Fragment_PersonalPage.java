package com.example.discovery.ibfsn.Fragments;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.DatePickerDialog;
import android.app.Dialog;
import android.app.DialogFragment;
import android.app.FragmentManager;
import android.content.Context;
import android.os.Build;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.text.Layout;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.DatePicker;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.example.discovery.ibfsn.Activites.Activity_Home;
import com.example.discovery.ibfsn.Objects.User;
import com.example.discovery.ibfsn.Others.AppSettings;
import com.example.discovery.ibfsn.Others.Main;
import com.example.discovery.ibfsn.R;
import com.squareup.picasso.Picasso;

import java.util.Calendar;
import java.util.Date;

import de.hdodenhof.circleimageview.CircleImageView;
import es.dmoral.toasty.Toasty;

/**
 * Created by Discovery on 08/05/2018.
 */

public class Fragment_PersonalPage extends Fragment {

    View rootView;
    CircleImageView imageViewPhotoUser;


    public static Fragment_PersonalPage newInstance() {
        Fragment_PersonalPage fragment = new Fragment_PersonalPage();
        return fragment;
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, Bundle savedInstanceState) {

        rootView = inflater.inflate(R.layout.fragment_pesonal_page, container, false);
        mLoadObjects();
        mLoadUI();
        mLoadActions();

        return  rootView;
    }


    private void mLoadObjects() {
    }

    private void mLoadUI() {

        imageViewPhotoUser = (CircleImageView)rootView.findViewById(R.id.imageViewPhotoUser);

        if (Main.user.getLinkPhoto() == null) {
            ((CircleImageView)rootView.findViewById(R.id.imageViewPhotoUser)).setImageResource(R.mipmap.logo_member);
        } else {
            Picasso.get().load(Main.user.getLinkPhoto()).into((CircleImageView)rootView.findViewById(R.id.imageViewPhotoUser));
        }

        ((TextView)rootView.findViewById(R.id.textViewName)).setText(Main.user.getName());
        ((TextView)rootView.findViewById(R.id.textViewNOFamilies)).setText(Main.getInstance().mGetNumberFamilyForUser(Main.user.getId())+"");


        if ( !(Main.user.getStatus() == null))
        switch (Main.user.getStatus()){
            case User.NORMAL: ((ImageView)rootView.findViewById(R.id.imageView3)).setBackgroundResource(R.mipmap.logo_face_1); break;
            case User.HAPPY: ((ImageView)rootView.findViewById(R.id.imageView3)).setBackgroundResource(R.mipmap.logo_face_2); break;
            case User.SAD: ((ImageView)rootView.findViewById(R.id.imageView3)).setBackgroundResource(R.mipmap.logo_face_3); break;

        }


    }

    private void mLoadActions() {

        ((TextView)rootView.findViewById(R.id.textViewDOB)).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Toasty.info(getActivity() , Main.user.getDateOfBirth() , Toast.LENGTH_SHORT, true).show();
            }
        });


        ((CircleImageView)rootView.findViewById(R.id.imageViewPhotoUser)).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                AlertDialog.Builder dialogBuilder = new AlertDialog.Builder(getContext());
                final ImageView imageViewPhoto = new ImageView(getContext());

                if (Main.user.getLinkPhoto() != null)
                Picasso.get().load(Main.user.getLinkPhoto()).into(imageViewPhoto);

                dialogBuilder.setView(imageViewPhoto);

                AlertDialog alertDialog = dialogBuilder.create();
                alertDialog.show();
            }
        });


        ((ImageView)rootView.findViewById(R.id.imageView1)).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                /*
                View layoutDOB = (View)rootView.findViewById(R.id.layoutDOB);
                layoutDOB.setVisibility(View.VISIBLE);

                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    ((DatePicker)rootView.findViewById(R.id.datePikerDOB)).setOnDateChangedListener(new DatePicker.OnDateChangedListener() {
                        @Override
                        public void onDateChanged(DatePicker datePicker, int i, int i1, int i2) {
                            Main.user.setDateOfBirth(i+"-"+i1+"-"+i2);
                            Toasty.info(getActivity() , i+"-"+i1+"-"+i2 , Toast.LENGTH_SHORT, true).show();
                        }
                    });
                } else {
                    Toasty.info(getActivity() , "This Step Need Version O or up" , Toast.LENGTH_SHORT, true).show();
                }
                */

                final Calendar myCalendar = Calendar.getInstance();
                DatePickerDialog.OnDateSetListener date = new DatePickerDialog.OnDateSetListener() {
                    @Override
                    public void onDateSet(DatePicker view, int year, int monthOfYear,
                                          int dayOfMonth) {
                        // TODO Auto-generated method stub
                        myCalendar.set(Calendar.YEAR, year);
                        myCalendar.set(Calendar.MONTH, monthOfYear);
                        myCalendar.set(Calendar.DAY_OF_MONTH, dayOfMonth);
                        Main.user.setDateOfBirth(year+"-"+monthOfYear+"-"+dayOfMonth);
                        Toasty.info(getActivity() , "Set DOB ("+ year+"-"+monthOfYear+"-"+dayOfMonth+")", Toast.LENGTH_SHORT, true).show();

                    }
                };


                new DatePickerDialog(getActivity(), date, myCalendar
                        .get(Calendar.YEAR), myCalendar.get(Calendar.MONTH),
                        myCalendar.get(Calendar.DAY_OF_MONTH)).show();
            }
        });


        ((ImageView)rootView.findViewById(R.id.imageView3)).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {


                if (!AppSettings.mIsNetworkAvailable(getActivity() , view))
                    return;

               final View layoutStatus = (View) rootView.findViewById(R.id.layoutStatus);
               layoutStatus.setVisibility(View.VISIBLE);

                ((ImageView)rootView.findViewById(R.id.imageViewFace1)).setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        Main.user.setStatus(User.NORMAL);
                        layoutStatus.setVisibility(View.GONE);
                        ((ImageView)rootView.findViewById(R.id.imageView3)).setBackgroundResource(R.mipmap.logo_face_1);
                    }
                });

                ((ImageView)rootView.findViewById(R.id.imageViewFace2)).setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        Main.user.setStatus(User.HAPPY);
                        layoutStatus.setVisibility(View.GONE);
                        ((ImageView)rootView.findViewById(R.id.imageView3)).setBackgroundResource(R.mipmap.logo_face_2);
                    }
                });

                ((ImageView)rootView.findViewById(R.id.imageViewFace3)).setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        Main.user.setStatus(User.SAD);
                        layoutStatus.setVisibility(View.GONE);
                        ((ImageView)rootView.findViewById(R.id.imageView3)).setBackgroundResource(R.mipmap.logo_face_3);
                    }
                });



            }
        });
    }


    public static class DatePickerFragment extends DialogFragment
            implements DatePickerDialog.OnDateSetListener {


        @Override
        public Dialog onCreateDialog(Bundle savedInstanceState) {
            // Use the current date as the default date in the picker
            final Calendar c = Calendar.getInstance();
            int year = c.get(Calendar.YEAR);
            int month = c.get(Calendar.MONTH);
            int day = c.get(Calendar.DAY_OF_MONTH);


            // Create a new instance of DatePickerDialog and return it
            return new DatePickerDialog(getActivity(), this, year, month, day);
        }

        public void onDateSet(DatePicker view, int year, int month, int day) {
            // Do something with the date chosen by the user
        }
    }


}
