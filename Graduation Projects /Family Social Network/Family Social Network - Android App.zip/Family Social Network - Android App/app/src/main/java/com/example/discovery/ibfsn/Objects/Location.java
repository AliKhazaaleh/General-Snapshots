package com.example.discovery.ibfsn.Objects;

import com.example.discovery.ibfsn.Others.AppSettings;
import com.example.discovery.ibfsn.Others.Main;

public class Location {

    private String id;
    private String idUser;
    private double locLat;
    private double locLon;
    private long date;

    public Location() {}

    public Location(String id, String idUser, double locLat, double locLon) {
        this.id = id;
        this.idUser = idUser;
        this.locLat = locLat;
        this.locLon = locLon;
        this.date = AppSettings.CurrentTimeMillis();
    }

    public Location(String id, String idUser, double locLat, double locLon, long date) {
        this.id = id;
        this.idUser = idUser;
        this.locLat = locLat;
        this.locLon = locLon;
        this.date = date;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getIdUser() {
        return idUser;
    }

    public void setIdUser(String idUser) {
        this.idUser = idUser;
    }

    public double getLocLat() {
        return locLat;
    }

    public void setLocLat(double locLat) {
        this.locLat = locLat;
    }

    public double getLocLon() {
        return locLon;
    }

    public void setLocLon(double locLon) {
        this.locLon = locLon;
    }

    public long getDate() {
        return date;
    }

    public void setDate(long date) {
        this.date = date;
    }
/*
    public User getUser(){
        return Main.getInstance().getMAPuser().get(idUser);
    }
*/
}
