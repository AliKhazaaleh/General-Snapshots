package com.example.discovery.ibfsn.Objects;

import android.media.MediaActionSound;

import com.example.discovery.ibfsn.Others.AppSettings;
import com.example.discovery.ibfsn.Others.Main;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Map;


public class MemberFamily {

    private String id;
    private String idUser;
    private String idFamily;
    private String adjective;
    private long date;

    public MemberFamily() {}

    public MemberFamily(String id, String idUser, String idFamily , String adjective) {
        this.id = id;
        this.idUser = idUser;
        this.idFamily = idFamily;
        this.adjective = adjective;
        this.date = AppSettings.CurrentTimeMillis();
    }

    public MemberFamily(String id, String idUser, String idFamily,String adjective, long date) {
        this.id = id;
        this.idUser = idUser;
        this.idFamily = idFamily;
        this.adjective = adjective;
        this.date = date;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getIdUser() {
        return idUser;
    }

    public void setIdUser(String idUser) {
        this.idUser = idUser;
    }

    public String getIdFamily() {
        return idFamily;
    }

    public void setIdFamily(String idFamily) {
        this.idFamily = idFamily;
    }

    public String getAdjective() {
        return adjective;
    }

    public void setAdjective(String adjective) {
        this.adjective = adjective;
    }

    public long getDate() {
        return date;
    }

    public void setDate(long date) {
        this.date = date;
    }

/*
    public User getUser(){
        return Main.getInstance().getMAPuser().get(idUser);
    }

    public Family getFamily(){
        return Main.getInstance().getMAPfamily().get(idFamily);
    }
*/
    public static String  FATHER = "FATHER";
    public static String  MOTHER = "MOTHER";
    public static String  GRANDSON = "GRANDSON";
    public static String  SON = "SON";
    public static String  GRANDMOTHER = "GRANDMOTHER";
    public static String  GRANDFATHER = "GRANDFATHER";

    public List<Location> mGetLastFiveLocations() {

        List<Location> LST = new ArrayList<>();

        for (Map.Entry<String , Location> item : Main.getInstance().getMAPlocation().entrySet() ){
            if (item.getValue().getIdUser().equals(getIdUser()))
                LST.add(item.getValue());
        }

        if (LST.size() > 0)
            Collections.sort(LST, new Comparator<Location>() {
                @Override
                public int compare(Location object1, Location objec2) {
                    return (object1.getDate()+"").compareTo(objec2.getDate()+"");
                }
            });

        Collections.reverse(LST);

        List<Location> LSTFive = new ArrayList<>();
        android.location.Location location = new android.location.Location("a");

        if (LST.size()>0)
        LSTFive.add(LST.get(0));

        for (Location item : LST) {

           location.setLatitude(LSTFive.get(LSTFive.size()-1).getLocLat() );
           location.setLatitude(LSTFive.get(LSTFive.size()-1).getLocLon() );

            android.location.Location temp = new android.location.Location("a");
            temp.setLongitude(item.getLocLon());
            temp.setLatitude(item.getLocLat());

           // 3600000 Mile = One Hour

            if (LSTFive.get(LSTFive.size()-1).getDate() - item.getDate() >= 3600000
                    || location.distanceTo(temp) > 70 ){
               LSTFive.add(item);
           }

            if (LSTFive.size() == 5)
                break;
        }

        return LSTFive;
    }
}

