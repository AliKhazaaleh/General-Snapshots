package com.example.discovery.ibfsn.Json;

import com.example.discovery.ibfsn.Objects.Admin;

/**
 * Created by Discovery on 18/04/2018.
 */

public class JsonAdmin {

    public String id;
    public String idFamily;
    public String idUser;

    public Admin ConvertToObject(){
        Admin admin = new Admin(id,idFamily,idUser);
        return admin;
    }
}
