package com.example.discovery.ibfsn.Objects;

import android.app.Activity;

import com.example.discovery.ibfsn.Activites.Activity_Comments;
import com.example.discovery.ibfsn.Activites.Activity_Family;
import com.example.discovery.ibfsn.Activites.Activity_MapPost;
import com.example.discovery.ibfsn.Json.JsonUser;
import com.example.discovery.ibfsn.Others.AppRefDB;
import com.example.discovery.ibfsn.Others.AppSettings;
import com.example.discovery.ibfsn.Others.Main;
import com.google.android.gms.auth.api.signin.GoogleSignInAccount;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.ValueEventListener;


public class User {

    // Varibles
    private String id;
    private String name;
    private String email;
    private String phone;
    private String status;
    private String linkPhoto;
    private long lastLogin;
    private String dateOfBirth;

    public User() {}

    public User(String id, String name, String email, String phone, String status, String linkPhoto, long lastLogin, String dateOfBirth) {
        this.id = id;
        this.name = name;
        this.email = email;
        this.phone = phone;
        this.status = status;
        this.linkPhoto = linkPhoto;
        this.lastLogin = lastLogin;
        this.dateOfBirth = dateOfBirth;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
        AppRefDB.RefUsers.child(this.getId()).child("phone").setValue(phone);
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
        AppRefDB.RefUsers.child(this.getId()).child("status").setValue(status);
    }

    public String getLinkPhoto() {
        return linkPhoto;
    }

    public void setLinkPhoto(String linkPhoto) {
        this.linkPhoto = linkPhoto;
    }

    public long getLastLogin() {
        return lastLogin;
    }

    public void setLastLogin(long lastLogin) {
        this.lastLogin = lastLogin;
    }

    public String getDateOfBirth() {
        return dateOfBirth;
    }

    public void setDateOfBirth(String dateOfBirth) {
        this.dateOfBirth = dateOfBirth;
       AppRefDB.RefUsers.child(this.getId()).child("dateOfBirth").setValue(dateOfBirth);
    }

    public void mLogInUser(GoogleSignInAccount acct, Activity context) {

        String vID = acct.getId();

        this.setId(vID);
        this.setName(acct.getDisplayName());
        this.setEmail(acct.getEmail());

        AppRefDB.RefUsers.child(vID).child("id").setValue(vID);
        AppRefDB.RefUsers.child(vID).child("name").setValue(acct.getDisplayName());
        AppRefDB.RefUsers.child(vID).child("email").setValue(acct.getEmail());
        AppRefDB.RefUsers.child(vID).child("lastLogin").setValue(AppSettings.CurrentTimeMillis());


        if (acct.getPhotoUrl() != null){
            setLinkPhoto(acct.getPhotoUrl().toString());
            AppRefDB.RefUsers.child(vID).child("linkPhoto").setValue(acct.getPhotoUrl().toString());
        }

        AppRefDB.RefUsers.child(vID).addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                Main.user = dataSnapshot.getValue(JsonUser.class).ConvertToObject();
            }
            @Override
            public void onCancelled(DatabaseError databaseError) {
            }
        });
    }

    // Create New Family
    public void mCreateFamily(String nameFamily , String linkPhoto , String adjectiveInFamily){

        String familyId = AppRefDB.RefFamilies.push().getKey();
        Family family = new Family( familyId ,nameFamily , linkPhoto);
        AppRefDB.RefFamilies.child(familyId).setValue(family);

        Main.getInstance().getMAPfamily().put(familyId , family);
        family.mAddAdmin(Main.user.getId() , adjectiveInFamily);
    }

    public void mCreatePost(String textPost , String linkPhoto , boolean flagLocation){

        String postId = AppRefDB.RefPosts.push().getKey();
        //  (String id, String idUser, String text,String idFamily, String privacy, String linkPhoto, double locLat,double locLon, long date, List<String> LSTuser)

        double lat = (flagLocation)? Activity_MapPost.LAT:0 ;
        double lon = (flagLocation)? Activity_MapPost.LON:0 ;

        Post post = new Post(postId , id , textPost , Activity_Family.idFamily , "" , linkPhoto ,lat,lon );
        Main.getInstance().getMAPpost().put(postId, post);
        AppRefDB.RefPosts.child(postId).setValue(post);
    }

    public void mAddLike(String idPost){
        String likeId = AppRefDB.RefLikes.push().getKey();
        Like like = new Like(likeId , id , idPost);
        AppRefDB.RefLikes.child(likeId).setValue(like);
    }

    public void mRemoveLike(String idPost){

        String idLike ="";
        for ( Like item :  Main.getInstance().getLSTlike(idPost) )
            if (item.getIdUser().equals(id) && item.getIdPostOrComment().equals(idPost))
                idLike = item.getId();

        if (Main.getInstance().getMAPlike().containsKey(idLike))
            Main.getInstance().getMAPlike().remove(idLike);

        AppRefDB.RefLikes.child(idLike).removeValue();
    }

    public void mAddCooment(String text){
        String commentId = AppRefDB.RefComments.push().getKey();
        Comment comment = new Comment(commentId , id, Activity_Comments.post.getId() , text);
        Main.getInstance().getMAPcomment().put(commentId , comment);
        AppRefDB.RefComments.child(commentId).setValue(comment);
    }

    public void mRemoveComment(String idCooment){
        AppRefDB.RefComments.child(idCooment).removeValue();
    }

    public final static String NORMAL = "NORMAL";
    public final static String HAPPY = "HAPPY";
    public final static String SAD = "SAD";

    public void mAddLastLocatio() {

        android.location.Location Nowlocation = new android.location.Location("a");
        Nowlocation.setLatitude(Activity_MapPost.LAT);
        Nowlocation.setLongitude(Activity_MapPost.LON);

        String id = AppRefDB.RefLocations.push().getKey();
        Location location = new Location(id, getId() , Nowlocation.getLatitude() ,Nowlocation.getLongitude() , AppSettings.CurrentTimeMillis());
        AppRefDB.RefLocations.child(id).setValue(location);

    }
}
