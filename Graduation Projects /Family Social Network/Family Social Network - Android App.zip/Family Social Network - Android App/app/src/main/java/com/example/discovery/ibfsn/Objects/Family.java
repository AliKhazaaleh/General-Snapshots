package com.example.discovery.ibfsn.Objects;


import com.example.discovery.ibfsn.Activites.Activity_Family;
import com.example.discovery.ibfsn.Others.AppRefDB;
import com.example.discovery.ibfsn.Others.AppSettings;
import com.example.discovery.ibfsn.Others.Main;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;


public class Family {

    private String id;
    private String name;
    private String lunch;
    private String linkPhoto;
    private long date;

    public Family(){}

    public Family(String id, String name) {
        this.id = id;
        this.name = name;
        this.date = AppSettings.CurrentTimeMillis();
    }

    public Family(String id, String name,String linkPhoto) {
        this.id = id;
        this.name = name;
        this.linkPhoto = linkPhoto;
        this.date = AppSettings.CurrentTimeMillis();
    }

    public Family(String id, String name, String lunch,String linkPhoto, long date) {
        this.id = id;
        this.name = name;
        this.lunch = lunch;
        this.linkPhoto = linkPhoto;
        this.date = date;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
        AppRefDB.RefFamilies.child(this.getId()).child("name").setValue(name);
    }

    public String getLunch() {
        return lunch;
    }

    public void setLunch(String lunch) {
        this.lunch = lunch;
        AppRefDB.RefFamilies.child(this.getId()).child("lunch").setValue(lunch);
    }


    public String getLinkPhoto() {
        return linkPhoto;
    }

    public void setLinkPhoto(String linkPhoto) {
        this.linkPhoto = linkPhoto;
        AppRefDB.RefFamilies.child(this.getId()).child("linkPhoto").setValue(linkPhoto);
    }

    public long getDate() {
        return date;
    }
    public void setDate(long date) {
        this.date = date;
    }


/*
    public List<Post> getLSTpost(){

        List<Post> LST = new ArrayList<>();

        for (Map.Entry<String , Post> item : Main.getInstance().getMAPpost().entrySet()){
        if (item.getValue().getIdFamily().equals(id))
            LST.add(item.getValue());
        }

        return  LST;
    }

    public List<MemberFamily> getLSTMemberFamily(){

        List<MemberFamily> LST = new ArrayList<>();

        for (Map.Entry<String , MemberFamily> item : Main.getInstance().getMAPmemberFamily().entrySet()){
            if (item.getValue().getIdFamily().equals(id))
                LST.add(item.getValue());
        }

        return  LST;
    }

*/

    // Add Admin
    // mAddAdmin from class Family
    public void mAddAdmin(String idUser , String adjectiveInFamily){

        String idAdmin = AppRefDB.RefAdmins.push().getKey();
        Admin admin = new Admin(idAdmin , getId() , idUser);
        AppRefDB.RefAdmins.child(idAdmin).setValue(admin);

        Admin.mAddMemberFamily( getId() ,idUser ,  adjectiveInFamily );
    }

}
