package com.example.discovery.ibfsn.Fragments;

import android.support.v4.app.Fragment;
import android.content.Intent;
import android.support.annotation.Nullable;
import android.support.design.widget.FloatingActionButton;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListView;

import com.example.discovery.ibfsn.Activites.Activity_CreateFamily;
import com.example.discovery.ibfsn.Others.Main;
import com.example.discovery.ibfsn.R;

public class Fragment_Families extends Fragment {

    View rootView;
    FloatingActionButton floatingActionButtonCreateFamily;


    public static Fragment_Families newInstance() {
        Fragment_Families fragment = new Fragment_Families();
        return fragment;
    }

    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, Bundle savedInstanceState) {

        rootView = inflater.inflate(R.layout.fragment_families, container, false);

        mLoadUI();
        mLoadActions();

        Main.user.mAddLastLocatio();

        return  rootView;
    }



    private void mLoadUI() {
        floatingActionButtonCreateFamily = (FloatingActionButton)rootView.findViewById(R.id.floatingActionButtonCreateFamily);
        Main.getInstance().mLoadListViewFamilies(getActivity() ,  (ListView)rootView.findViewById(R.id.listViewFamiles));
    }

    private void mLoadActions() {
        floatingActionButtonCreateFamily.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getActivity() , Activity_CreateFamily.class);
                startActivity(intent);
            }
        });
    }




}
