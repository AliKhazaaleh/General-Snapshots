package com.example.discovery.ibfsn.Activites;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import com.example.discovery.ibfsn.R;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;

public class Activity_MapPost extends AppCompatActivity implements OnMapReadyCallback {

    // AIzaSyDlu8UH0L3onTn9hMMA9-hTuKlvytmT-nI
    public static double LAT;
    public static  double LON;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_map_post);

        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager().findFragmentById(R.id.map);
        mapFragment.getMapAsync(this);

    }

    @Override
    public void onMapReady(GoogleMap googleMap) {

        LatLng sydney = new LatLng( getIntent().getExtras().getDouble("lat"), getIntent().getExtras().getDouble("lon"));
        googleMap.addMarker(new MarkerOptions().position(sydney)
                .title("My Home"));

        googleMap.moveCamera(CameraUpdateFactory.newLatLngZoom(new LatLng(getIntent().getExtras().getDouble("lat"), getIntent().getExtras().getDouble("lon")) ,14));
    }

}
