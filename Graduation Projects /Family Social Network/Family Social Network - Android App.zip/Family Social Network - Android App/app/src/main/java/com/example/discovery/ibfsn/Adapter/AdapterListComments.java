package com.example.discovery.ibfsn.Adapter;

import android.app.Activity;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;

import com.example.discovery.ibfsn.Objects.Comment;
import com.example.discovery.ibfsn.Objects.Post;
import com.example.discovery.ibfsn.Others.AppSettings;
import com.example.discovery.ibfsn.Others.Main;
import com.example.discovery.ibfsn.R;
import com.squareup.picasso.Picasso;

import java.util.Date;
import java.util.List;

import de.hdodenhof.circleimageview.CircleImageView;

/**
 * Created by Discovery on 04/05/2018.
 */

public class AdapterListComments extends ArrayAdapter<Comment> {

    private Activity context;
    private List<Comment> LST;

    public AdapterListComments(Activity context, List<Comment> LST) {
        super(context, R.layout.item_comment, LST);

        this.context = context;
        this.LST = LST;
    }


    public View getView(final int position, final View convertView, ViewGroup parent) {

        LayoutInflater layoutInflater = context.getLayoutInflater();
        final View viewItem = layoutInflater.inflate(R.layout.item_comment, null, true);

        // for photo user
        if ( Main.getInstance().getMAPuser().get( LST.get(position).getIdUser()).getLinkPhoto() == null) {
            ((CircleImageView)viewItem.findViewById(R.id.circleImageViewPhotoMember)).setImageResource(R.mipmap.logo_member);
        } else{
            Picasso.get().load(Main.getInstance().getMAPuser().get( LST.get(position).getIdUser()).getLinkPhoto()).into((CircleImageView)viewItem.findViewById(R.id.circleImageViewPhotoMember));
        }

        ((TextView)viewItem.findViewById(R.id.textViewMemberName)).setText( "" + Main.getInstance().getMAPuser().get(LST.get(position).getIdUser()).getName());

        Date d = new Date(LST.get(position).getDate());
        ((TextView)viewItem.findViewById(R.id.textViewDateComment)).setText(d.toString());
        ((TextView)viewItem.findViewById(R.id.textViewTextOfComment)).setText(LST.get(position).getText());

        if (!LST.get(position).getIdUser().equals(Main.user.getId()))
            ((Button)viewItem.findViewById(R.id.buttonDeleteComment)).setVisibility(View.GONE);

        ((Button)viewItem.findViewById(R.id.buttonDeleteComment)).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if (!AppSettings.mIsNetworkAvailable(context , view))
                    return;

                Main.user.mRemoveComment(LST.get(position).getId());
                viewItem.setVisibility(View.GONE);

            }
        });

        return viewItem;
    }
}
