package com.example.discovery.ibfsn.Json;

import com.example.discovery.ibfsn.Objects.Comment;

/**
 * Created by Discovery on 18/04/2018.
 */

public class JsonComment {

    public String id;
    public String idUser;
    public String idPost;
    public String text;
    public long date;

    public Comment ConvertToObject(){
        Comment comment = new Comment( id,  idUser,  idPost,  text,  date);
        return comment;
    }

}
