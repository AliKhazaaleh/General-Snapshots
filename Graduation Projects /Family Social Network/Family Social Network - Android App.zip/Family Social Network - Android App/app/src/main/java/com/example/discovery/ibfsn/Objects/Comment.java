package com.example.discovery.ibfsn.Objects;


import com.example.discovery.ibfsn.Others.AppSettings;
import com.example.discovery.ibfsn.Others.Main;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;


public class Comment {

    private String id;
    private String idUser;
    private String idPost;
    private String text;
    private long date;

    public Comment() {
        // Default constructor required for calls to DataSnapshot.getValue(Comment.class)
    }

    public Comment(String id, String idUser, String idPost, String text) {
        this.id = id;
        this.idUser = idUser;
        this.idPost = idPost;
        this.text = text;
        this.date = AppSettings.CurrentTimeMillis();
    }

    public Comment(String id, String idUser, String idPost, String text, long date) {
        this.id = id;
        this.idUser = idUser;
        this.idPost = idPost;
        this.text = text;
        this.date = date;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getIdUser() {
        return idUser;
    }

    public void setIdUser(String idUser) {
        this.idUser = idUser;
    }

    public String getIdPost() {
        return idPost;
    }

    public void setIdPost(String idPost) {
        this.idPost = idPost;
    }

    public String getText() {
        return text;
    }

    public void setText(String text) {
        this.text = text;
    }

    public long getDate() {
        return date;
    }

    public void setDate(long date) {
        this.date = date;
    }

    /*
    public List<Like> getLSTlike(){
        List<Like> LST = new ArrayList<>();
        for (Map.Entry<String , Like> item : Main.getInstance().getMAPlike().entrySet()  ){
            if (item.getValue().getIdPostOrComment().equals(id))
                LST.add(item.getValue());
        }
        return LST;
    }
    */
}
