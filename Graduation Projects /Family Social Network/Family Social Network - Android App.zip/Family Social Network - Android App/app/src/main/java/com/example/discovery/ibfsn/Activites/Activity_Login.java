package com.example.discovery.ibfsn.Activites;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.Location;
import android.location.LocationManager;
import android.os.Bundle;
import android.os.Handler;
import android.provider.Settings;
import android.support.design.widget.Snackbar;
import android.support.v4.app.ActivityCompat;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import com.example.discovery.ibfsn.Others.AppSettings;
import com.example.discovery.ibfsn.Others.Main;
import com.example.discovery.ibfsn.R;
import com.google.android.gms.auth.api.Auth;
import com.google.android.gms.auth.api.signin.GoogleSignInAccount;
import com.google.android.gms.auth.api.signin.GoogleSignInOptions;
import com.google.android.gms.auth.api.signin.GoogleSignInResult;
import com.google.android.gms.common.SignInButton;
import com.google.android.gms.common.api.GoogleApiClient;

import es.dmoral.toasty.Toasty;

import static com.example.discovery.ibfsn.Others.AppSettings.mLoadColorToasty;

public class Activity_Login extends AppCompatActivity {


    SignInButton buttonSignInButtonGmail;
    GoogleSignInOptions gso;
    GoogleApiClient mGoogleApiClient;
    int RC_SIGN_IN=10;
    View v;

    Context context;
    Button buttonSetLocation;
    private static final int REQUEST_LOCATION = 1;
    LocationManager locationManager;
    String lattitude, longitude;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        AppSettings.mLoadColorToasty();

        mLoadObjects();
        mLoadUI();
        mLoadActions();


        Main.getInstance().mLoadUsers();
        Main.getInstance().mLoadAdmins();
        Main.getInstance().mLoadComments();
        Main.getInstance().mLoadFamilies();
        Main.getInstance().mLoadLikes();
        Main.getInstance().mLoadLocations();
        Main.getInstance().mLoadMemberFamily();
        Main.getInstance().mLoadPosts();


    }


    private void mLoadObjects() {
        gso = new GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
                .requestEmail()
                .build();

        mGoogleApiClient = new GoogleApiClient.Builder(this)
                .addApi(Auth.GOOGLE_SIGN_IN_API, gso)
                .build();
    }


    private void mLoadUI() {

        buttonSignInButtonGmail = (SignInButton) findViewById(R.id.buttonSignInButtonGmail);
        buttonSetLocation = (Button)findViewById(R.id.buttonSetLocation);
        v = buttonSignInButtonGmail;
        buttonSignInButtonGmail.setVisibility(View.GONE);
    }

    private void mLoadActions() {
        buttonSignInButtonGmail.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if (!AppSettings.mIsNetworkAvailable(Activity_Login.this , v)){
                    return;
                }
                signIn();

            }
        });

        buttonSetLocation.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
             mOnClick_button_get_location();
            }
        });
    }

    // Start Methods Sign IN GOOGLE
    private void signIn() {
        Intent signInIntent = Auth.GoogleSignInApi.getSignInIntent(mGoogleApiClient);
        startActivityForResult(signInIntent, RC_SIGN_IN);
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        // Result returned from launching the Intent from GoogleSignInApi.getSignInIntent(...);
        if (requestCode == RC_SIGN_IN) {
            GoogleSignInResult result = Auth.GoogleSignInApi.getSignInResultFromIntent(data);
            handleSignInResult(result);
        }
        else {
            Snackbar.make( v , "خطأ في عملية الدخول", Snackbar.LENGTH_LONG)
                    .setAction("Action", null).show();        }
    }

    private void handleSignInResult(GoogleSignInResult result) {
        if (result.isSuccess()) {
            // Signed in successfully,
            GoogleSignInAccount acct = result.getSignInAccount();
            Main.user.mLogInUser(acct , Activity_Login.this );

           // Toast.makeText(getBaseContext(), acct.getEmail().toString() , Toast.LENGTH_SHORT).show();
           // Toast.makeText(this, Main.getInstance().getMAPuser().size()+"" , Toast.LENGTH_SHORT).show();

            Intent intent = new Intent(Activity_Login.this , Activity_Home.class);
            startActivity(intent);

        } else {
            Snackbar.make( v , "خطأ في الاتصال بالشبكة", Snackbar.LENGTH_LONG)
                    .setAction("Action", null).show();
        }
    }


    public void mOnClick_button_get_location() {

        locationManager = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
        if (!locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER)) {
            buildAlertMessageNoGps();
        } else if (locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER)) {
            getLocation();
        }
    }

    private void getLocation() {
        if (ActivityCompat.checkSelfPermission(Activity_Login.this, android.Manifest.permission.ACCESS_FINE_LOCATION)
                != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission
                (Activity_Login.this, android.Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {

            ActivityCompat.requestPermissions(Activity_Login.this, new String[]{android.Manifest.permission.ACCESS_FINE_LOCATION}, REQUEST_LOCATION);

        } else {

            Location location = locationManager.getLastKnownLocation(LocationManager.NETWORK_PROVIDER);

            if (location != null) {
                double latti = location.getLatitude();
                double longi = location.getLongitude();
                lattitude = String.valueOf(latti);
                longitude = String.valueOf(longi);
                Activity_MapPost.LAT = latti;
                Activity_MapPost.LON = longi;

                /*
                Toast.makeText(getBaseContext(), "Your current location is"+ "\n" + "Lattitude = " + lattitude
                        + "\n" + "Longitude = " + longitude, Toast.LENGTH_SHORT).show();
*/

                Toasty.success( getBaseContext(), "Success", Toast.LENGTH_SHORT, true).show();

                ((Button)findViewById(R.id.buttonSetLocation)).setEnabled(false);
                buttonSignInButtonGmail.setVisibility(View.VISIBLE);

            }else{
                Toasty.warning( getBaseContext(), "Some Time .... Or Restart Gps", Toast.LENGTH_SHORT, true).show();
            }

        }
    }

    protected void buildAlertMessageNoGps() {

        final AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setMessage("Please Turn ON your GPS Connection")
                .setCancelable(false)
                .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                    public void onClick(final DialogInterface dialog, final int id) {
                        startActivity(new Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS));
                    }
                })
                .setNegativeButton("No", new DialogInterface.OnClickListener() {
                    public void onClick(final DialogInterface dialog, final int id) {
                        dialog.cancel();
                    }
                });
        final AlertDialog alert = builder.create();
        alert.show();
    }

}
