package com.example.discovery.ibfsn.Activites;

import android.content.ContentResolver;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Handler;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.webkit.MimeTypeMap;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.Spinner;
import android.widget.Toast;

import com.example.discovery.ibfsn.Fragments.Fragment_Families;
import com.example.discovery.ibfsn.Objects.MemberFamily;
import com.example.discovery.ibfsn.Others.AppRefDB;
import com.example.discovery.ibfsn.Others.AppSettings;
import com.example.discovery.ibfsn.Others.Main;
import com.example.discovery.ibfsn.R;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.storage.OnProgressListener;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.StorageTask;
import com.google.firebase.storage.UploadTask;

import java.io.FileNotFoundException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

import es.dmoral.toasty.Toasty;

public class Activity_CreateFamily extends AppCompatActivity {


    private static final int PICK_IMAGE_REQUEST = 1;

    private EditText editTextNameFamily;
    private ImageView imageViewFamily;
    private ProgressBar progress_bar;
    private Spinner spinnerAdjective;
    private Button buttonCreateFamily;
    private Uri mImageUri;

    private StorageTask mUploadTask;



    List<String> LSTspinnerAdjective;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_create_family);

        mLoadObjects();
        mLoadUI();
        mLoadActions();
    }

    private void mLoadObjects() {

        LSTspinnerAdjective = new ArrayList<>();
        LSTspinnerAdjective.add(MemberFamily.FATHER);
        LSTspinnerAdjective.add(MemberFamily.MOTHER);
        LSTspinnerAdjective.add(MemberFamily.SON);
        LSTspinnerAdjective.add(MemberFamily.GRANDSON);
        LSTspinnerAdjective.add(MemberFamily.GRANDFATHER);
        LSTspinnerAdjective.add(MemberFamily.GRANDMOTHER);

    }

    private void mLoadUI() {
        editTextNameFamily = (EditText)findViewById(R.id.editTextNameFamily);
        imageViewFamily = (ImageView) findViewById(R.id.imageViewFamily);
        progress_bar = (ProgressBar) findViewById(R.id.progress_bar);
        spinnerAdjective = (Spinner)findViewById(R.id.spinnerAdjective);
        buttonCreateFamily = (Button)findViewById(R.id.buttonCreateFamily);

        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this,
                android.R.layout.simple_spinner_dropdown_item , LSTspinnerAdjective);
        spinnerAdjective.setAdapter(adapter);

    }

    private void mLoadActions() {

        imageViewFamily.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openFileChooser();
            }
        });

        buttonCreateFamily.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if (!AppSettings.mIsNetworkAvailable(Activity_CreateFamily.this , view)){
                    return;
                }

                if (editTextNameFamily.getText().toString().length() <= 5 ){
                    Toasty.warning( getBaseContext(), "Name Family must More Than 5 char", Toast.LENGTH_SHORT, true).show();
                    return;
                }

                if (mUploadTask != null && mUploadTask.isInProgress()) {
                    Toasty.warning( getBaseContext(), "Upload in progress", Toast.LENGTH_SHORT, true).show();
                } else {
                     uploadFile();
                }
            }
        });
    }

    private void openFileChooser() {
        Intent intent = new Intent();
        intent.setType("image/*");
        intent.setAction(Intent.ACTION_GET_CONTENT);
        startActivityForResult(intent, PICK_IMAGE_REQUEST);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        try {
            if (requestCode == PICK_IMAGE_REQUEST && resultCode == RESULT_OK
                    && data != null && data.getData() != null) {
                mImageUri = data.getData();
                final Uri imageUri = data.getData();
                final InputStream imageStream;
                imageStream = getContentResolver().openInputStream(imageUri);

                final Bitmap selectedImage = BitmapFactory.decodeStream(imageStream);
                imageViewFamily.setImageBitmap(selectedImage);
            }

        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
    }

    private String getFileExtension(Uri uri) {
        ContentResolver cR = getContentResolver();
        MimeTypeMap mime = MimeTypeMap.getSingleton();
        return mime.getExtensionFromMimeType(cR.getType(uri));
    }

    private void uploadFile() {

        if (mImageUri != null) {
            StorageReference fileReference = AppRefDB.mStorageRef.child(System.currentTimeMillis()
                    + "." + getFileExtension(mImageUri));

            mUploadTask = fileReference.putFile(mImageUri)
                    .addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
                        @Override
                        public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {
                            Handler handler = new Handler();
                            handler.postDelayed(new Runnable() {
                                @Override
                                public void run() {
                                    progress_bar.setProgress(0);
                                }
                            }, 500);

                            Main.user.mCreateFamily(editTextNameFamily.getText().toString() , taskSnapshot.getDownloadUrl() != null ? taskSnapshot.getDownloadUrl().toString() : "" , spinnerAdjective.getSelectedItem().toString());
                            Toasty.success( getBaseContext(), "Upload successful", Toast.LENGTH_SHORT, true).show();
                            buttonCreateFamily.setEnabled(false);

                            Intent intent = new Intent(Activity_CreateFamily.this , Activity_Home.class);
                            startActivity(intent);
                        }
                    })
                    .addOnFailureListener(new OnFailureListener() {
                        @Override
                        public void onFailure(@NonNull Exception e) {
                            Toasty.error( getBaseContext(), e.getMessage(), Toast.LENGTH_SHORT, true).show();
                        }
                    })
                    .addOnProgressListener(new OnProgressListener<UploadTask.TaskSnapshot>() {
                        @Override
                        public void onProgress(UploadTask.TaskSnapshot taskSnapshot) {
                            double progress = (100.0 * taskSnapshot.getBytesTransferred() / taskSnapshot.getTotalByteCount());
                            progress_bar.setProgress((int) progress);
                        }
                    });
        } else {
            Toasty.warning( getBaseContext(), "No file selected", Toast.LENGTH_SHORT, true).show();
          //  buttonCreateFamily.setEnabled(true);
        }
    }

}
