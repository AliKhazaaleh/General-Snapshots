package com.example.discovery.ibfsn.Json;

import com.example.discovery.ibfsn.Objects.Post;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by Discovery on 18/04/2018.
 */

public class JsonPost {

    public String id;
    public String idUser;
    public String text;
    public String idFamily;
    public String privacy;
    public String linkPhoto;
    public double locLat;
    public double locLon;
    public long date;
    public List<String> LSTuser = new ArrayList<>();

    public Post ConvertToObject(){
        Post post = new Post( id,  idUser,  text, idFamily,  privacy, linkPhoto,locLat,locLon, date, LSTuser);
        return post;
    }
}
