package com.example.discovery.ibfsn.Adapter;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.support.design.widget.Snackbar;
import android.support.v4.app.ActivityCompat;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.example.discovery.ibfsn.Activites.Activity_MapMember;
import com.example.discovery.ibfsn.Activites.Activity_MapPost;
import com.example.discovery.ibfsn.Objects.MemberFamily;
import com.example.discovery.ibfsn.Objects.User;
import com.example.discovery.ibfsn.Others.Main;
import com.example.discovery.ibfsn.R;
import com.squareup.picasso.Picasso;

import java.util.List;

import de.hdodenhof.circleimageview.CircleImageView;
import es.dmoral.toasty.Toasty;

/**
 * Created by Discovery on 30/04/2018.
 */

public class AdapterListMembers extends ArrayAdapter<MemberFamily> {

    private Activity context;
    private List<MemberFamily> LST;

    public AdapterListMembers(Activity context, List<MemberFamily> LST) {
        super(context, R.layout.item_member, LST);

        this.context = context;
        this.LST = LST;
    }


    public View getView(final int position, final View convertView, ViewGroup parent) {

        LayoutInflater layoutInflater = context.getLayoutInflater();
        final View viewItem = layoutInflater.inflate(R.layout.item_member, null, true);

        ((TextView)viewItem.findViewById(R.id.textViewNameMember)).setText(Main.getInstance().getMAPuser().get( LST.get(position).getIdUser()).getName());
        ((TextView)viewItem.findViewById(R.id.textViewAdjective)).setText(LST.get(position).getAdjective());

        if ( Main.getInstance().getMAPuser().get( LST.get(position).getIdUser()).getLinkPhoto() == null) {
            ((CircleImageView)viewItem.findViewById(R.id.imageViewPhotoMember)).setImageResource(R.mipmap.logo_member);
        } else{
            Picasso.get().load(Main.getInstance().getMAPuser().get( LST.get(position).getIdUser()).getLinkPhoto()).into((CircleImageView)viewItem.findViewById(R.id.imageViewPhotoMember));
        }

        if ( Main.getInstance().getMAPuser().get( LST.get(position).getIdUser()).getStatus() == null
                || Main.getInstance().getMAPuser().get( LST.get(position).getIdUser()).getStatus() =="" ) {
            ((ImageView)viewItem.findViewById(R.id.imageViewState)).setImageResource(R.mipmap.logo_face_1);
        } else{
            switch ( Main.getInstance().getMAPuser().get( LST.get(position).getIdUser()).getStatus()){
                case User.NORMAL:
                    ((ImageView)viewItem.findViewById(R.id.imageViewState)).setImageResource(R.mipmap.logo_face_1);
                    break;
                case User.HAPPY:
                    ((ImageView)viewItem.findViewById(R.id.imageViewState)).setImageResource(R.mipmap.logo_face_2);
                    break;
                case User.SAD:
                    ((ImageView)viewItem.findViewById(R.id.imageViewState)).setImageResource(R.mipmap.logo_face_3);
                    break;
            }
        }

        ((CircleImageView)viewItem.findViewById(R.id.imageViewPhotoMember)).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                AlertDialog.Builder dialogBuilder = new AlertDialog.Builder(context);
                final ImageView imageViewPhoto = new ImageView(context);

                Picasso.get().load(Main.getInstance().getMAPuser().get( LST.get(position).getIdUser()).getLinkPhoto()).into(imageViewPhoto);
                dialogBuilder.setView(imageViewPhoto);

                AlertDialog alertDialog = dialogBuilder.create();
                alertDialog.show();
            }
        });

        ((ImageView)viewItem.findViewById(R.id.imageViewCall)).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if (Main.getInstance().getMAPuser().get( LST.get(position).getIdUser()).getPhone() == null
                        || Main.getInstance().getMAPuser().get( LST.get(position).getIdUser()).getPhone().equals("") ){
                    Toasty.warning(getContext() , "Not auto... mobile number", Toast.LENGTH_SHORT, true).show();

                    return;
                }

                final AlertDialog.Builder builder = new AlertDialog.Builder(context);
                builder.setMessage("هل ترغب بالتواصل معه ... اذا قمت باختيار نعم سوف تقوم بالإتصال به ؟")
                        .setCancelable(false)
                        .setPositiveButton("نعم", new DialogInterface.OnClickListener() {
                            public void onClick(final DialogInterface dialog, final int id) {

                                Intent intent = new Intent(Intent.ACTION_CALL, Uri.parse("tel:" + Main.getInstance().getMAPuser().get(LST.get(position).getIdUser()).getPhone()));
                                if (ActivityCompat.checkSelfPermission(context , Manifest.permission.CALL_PHONE) != PackageManager.PERMISSION_GRANTED) {
                                    // TODO: Consider calling
                                    //    ActivityCompat#requestPermissions
                                    // here to request the missing permissions, and then overriding
                                    //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
                                    //                                          int[] grantResults)
                                    // to handle the case where the user grants the permission. See the documentation
                                    // for ActivityCompat#requestPermissions for more details.
                                    return;
                                }
                                context.startActivity(intent);
                            }
                        })
                        .setNegativeButton("لا", new DialogInterface.OnClickListener() {
                            public void onClick(final DialogInterface dialog, final int id) {
                                dialog.cancel();
                            }
                        });

                final AlertDialog alert = builder.create();
                alert.show();

            }
        });

        ((ImageView)viewItem.findViewById(R.id.imageViewLocation)).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent intent = new Intent(context , Activity_MapMember.class);
                Activity_MapMember.idMember = LST.get(position).getId();
                context.startActivity(intent);
            }
        });

        ((ImageView)viewItem.findViewById(R.id.imageViewDOB)).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if (Main.getInstance().getMAPuser().get( LST.get(position).getIdUser()).getDateOfBirth() == null
                        || Main.getInstance().getMAPuser().get( LST.get(position).getIdUser()).getDateOfBirth().equals("") ){
                    Toasty.warning( getContext(), "Not add DOB this User", Toast.LENGTH_SHORT, true).show();

                    return;
                }

                Snackbar.make(view, Main.getInstance().getMAPuser().get(LST.get(position).getIdUser()).getDateOfBirth()+"", Snackbar.LENGTH_LONG)
                        .setAction("Action", null).show();

            }
        });

       /*
        Glide.with(((CircleImageView)viewItem.findViewById(R.id.imageViewPhotoFamily)).getContext())
                .load("link")
                .into(((CircleImageView)viewItem.findViewById(R.id.imageViewPhotoFamily)));
*/
        return  viewItem;
    }
}
