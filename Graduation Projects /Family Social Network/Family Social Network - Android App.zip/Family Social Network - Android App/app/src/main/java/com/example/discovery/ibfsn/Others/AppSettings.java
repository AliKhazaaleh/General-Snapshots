package com.example.discovery.ibfsn.Others;

import android.app.Activity;
import android.content.Context;
import android.graphics.Color;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.support.design.widget.Snackbar;
import android.view.View;

import java.util.Calendar;
import java.util.Date;

import es.dmoral.toasty.Toasty;


public class AppSettings {


    public static String ConvertTimeToFormat (long time){

        String time_format = String.valueOf( (time/3600000)%24 ) +":"+ String.valueOf((time%3600000)/60000 )+":"+ String.valueOf( (time%3600000)%60000/1000 );
        return time_format;

    }

    public static long ConvertTimeToMillis(String time){

        String[]parts = time.split(":");
        long timeMil = Long.parseLong( parts[0] ) * 3600000 + Long.parseLong( parts[1] ) * 60000 ;

        return timeMil;
    }

    public static long CurrentTimeMillis (){
        return Calendar.getInstance().getTimeInMillis();
    }



    public static Date CurrentTime(){
        Date currentTime = Calendar.getInstance().getTime();
        return currentTime;
    }
    public static boolean mIsNetworkAvailable(Activity context , View view) {


        ConnectivityManager connectivityManager
                = (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo activeNetworkInfo = connectivityManager.getActiveNetworkInfo();

        if (activeNetworkInfo != null && activeNetworkInfo.isConnected()){
            return true;
        }else {
            Snackbar.make(view, "لا يوجد اتصال بالشبكة", Snackbar.LENGTH_LONG)
                    .setAction("Action", null).show();
            return  false;
        }

    }

    public static void mLoadColorToasty (){
        Toasty.Config.getInstance()
                .setSuccessColor(Color.parseColor("#3F51B5"))
                .setWarningColor(Color.parseColor("#434343"))
                .setErrorColor(Color.parseColor("#d44837"))
                .setTextColor(Color.parseColor("#ffffff"))
                .apply();

    }

}
