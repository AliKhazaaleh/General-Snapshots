package com.example.discovery.ibfsn.Others;

import android.app.Activity;
import android.widget.ListView;

import com.example.discovery.ibfsn.Activites.Activity_Comments;
import com.example.discovery.ibfsn.Activites.Activity_Family;
import com.example.discovery.ibfsn.Adapter.AdapterListComments;
import com.example.discovery.ibfsn.Adapter.AdapterListFamilies;
import com.example.discovery.ibfsn.Adapter.AdapterListMembers;
import com.example.discovery.ibfsn.Adapter.AdapterListPosts;
import com.example.discovery.ibfsn.Json.JsonAdmin;
import com.example.discovery.ibfsn.Json.JsonComment;
import com.example.discovery.ibfsn.Json.JsonFamily;
import com.example.discovery.ibfsn.Json.JsonLike;
import com.example.discovery.ibfsn.Json.JsonLocation;
import com.example.discovery.ibfsn.Json.JsonMemberFamily;
import com.example.discovery.ibfsn.Json.JsonPost;
import com.example.discovery.ibfsn.Json.JsonUser;
import com.example.discovery.ibfsn.Objects.Admin;
import com.example.discovery.ibfsn.Objects.Comment;
import com.example.discovery.ibfsn.Objects.Family;
import com.example.discovery.ibfsn.Objects.Like;
import com.example.discovery.ibfsn.Objects.MemberFamily;
import com.example.discovery.ibfsn.Objects.User;
import com.example.discovery.ibfsn.Objects.Post;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;


public class Main {

    private static final Main ourInstance = new Main();
    public static User user = new User();

    private HashMap<String , User> MAPuser = new HashMap<>();
    private HashMap<String , Admin> MAPadmin = new HashMap<>();
    private HashMap<String , Comment> MAPcomment = new HashMap<>();
    private HashMap<String , Family> MAPfamily = new HashMap<>();
    private HashMap<String , Like> MAPlike = new HashMap<>();
    private HashMap<String , com.example.discovery.ibfsn.Objects.Location> MAPlocation = new HashMap<>();
    private HashMap<String , MemberFamily> MAPmemberFamily = new HashMap<>();
    private HashMap<String , Post> MAPpost = new HashMap<>();
    // private HashMap<String , > MAP = new HashMap<>();

    public static Main getInstance() {
        return ourInstance;
    }

    private Main() {
    }

    public void mLoadUsers(){
        AppRefDB.RefUsers.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {

                MAPuser.clear();
                for (DataSnapshot dataSnapshot_user : dataSnapshot.getChildren()){
                    User user  =  dataSnapshot_user.getValue(JsonUser.class).ConvertToObject();
                    MAPuser.put(user.getId() , user );
                }
            }
            @Override
            public void onCancelled(DatabaseError databaseError) {
            }
        });
    }

    public void mLoadAdmins(){

        AppRefDB.RefAdmins.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                MAPadmin.clear();
                for (DataSnapshot dataSnapshot_admin : dataSnapshot.getChildren()){
                     Admin admin = dataSnapshot_admin.getValue(JsonAdmin.class).ConvertToObject();
                     MAPadmin.put(admin.getId() , admin );
                }
            }
            @Override
            public void onCancelled(DatabaseError databaseError) {
            }
        });
    }

    public void mLoadComments(){

        AppRefDB.RefComments.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                MAPcomment.clear();
                for (DataSnapshot dataSnapshot_comment : dataSnapshot.getChildren()){
                     Comment comment = dataSnapshot_comment.getValue(JsonComment.class).ConvertToObject();
                     MAPcomment.put(comment.getId() , comment );
                }
            }
            @Override
            public void onCancelled(DatabaseError databaseError) {
            }
        });
    }

    public void mLoadFamilies(){

        AppRefDB.RefFamilies.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                MAPfamily.clear();
                for (DataSnapshot dataSnapshot_family : dataSnapshot.getChildren()){
                    Family  family = dataSnapshot_family.getValue(JsonFamily.class).ConvertToObject();
                    MAPfamily.put(family.getId(), family );
                }
            }
            @Override
            public void onCancelled(DatabaseError databaseError) {
            }
        });
    }

    public void mLoadLikes(){

        AppRefDB.RefLikes.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                MAPlike.clear();
                for (DataSnapshot dataSnapshot_like : dataSnapshot.getChildren()){
                    Like like= dataSnapshot_like.getValue(JsonLike.class).ConvertToObject();
                    MAPlike.put(like.getId() , like );
                }
            }
            @Override
            public void onCancelled(DatabaseError databaseError) {
            }
        });
    }

    public void mLoadLocations(){

        AppRefDB.RefLocations.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                MAPlocation.clear();
                for (DataSnapshot dataSnapshot_location : dataSnapshot.getChildren()){
                     com.example.discovery.ibfsn.Objects.Location location = dataSnapshot_location.getValue(JsonLocation.class).ConvertToObject();
                    MAPlocation.put(location.getId() , location  );
                }
            }
            @Override
            public void onCancelled(DatabaseError databaseError) {
            }
        });
    }

    public void mLoadMemberFamily(){

        AppRefDB.RefMembersFamily.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                MAPmemberFamily.clear();
                for (DataSnapshot dataSnapshot_memberfamily : dataSnapshot.getChildren()){
                    MemberFamily memberFamily  = dataSnapshot_memberfamily.getValue(JsonMemberFamily.class).ConvertToObject();
                    MAPmemberFamily.put( memberFamily.getId() ,memberFamily  );
                }
            }
            @Override
            public void onCancelled(DatabaseError databaseError) {
            }
        });
    }

    public void mLoadPosts(){

        AppRefDB.RefPosts.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                MAPpost.clear();
                for (DataSnapshot dataSnapshot_post : dataSnapshot.getChildren()){
                    Post post = dataSnapshot_post.getValue(JsonPost.class).ConvertToObject();
                    MAPpost.put(post.getId() , post );
                }
            }
            @Override
            public void onCancelled(DatabaseError databaseError) {
            }
        });
    }


    public void mLoadListViewFamilies(final Activity conntext, final ListView listViewFamilies ){

        List<Family> LST = new ArrayList<>();
        for (Map.Entry<String , MemberFamily > item : getMAPmemberFamily().entrySet() )
            if (item.getValue().getIdUser().equals(Main.user.getId())){
                LST.add(getMAPfamily().get(item.getValue().getIdFamily()));
            }

        AdapterListFamilies Adapter = new AdapterListFamilies(conntext , LST);
        listViewFamilies.setAdapter(Adapter);
    }


    public void mLoadListViewMembers(final Activity conntext, final ListView listViewMembers ){

        List<MemberFamily> LST = new ArrayList<>();

        for (Map.Entry<String , MemberFamily > item : getMAPmemberFamily().entrySet() )
            if (item.getValue().getIdFamily().equals(Activity_Family.idFamily)){
                LST.add(item.getValue());
            }

        AdapterListMembers Adapter = new AdapterListMembers(conntext , LST);
        listViewMembers.setAdapter(Adapter);
    }

    public void mLoadListViewPosts(final Activity conntext, final ListView listViewPosts ){

        List<Post> LST = new ArrayList<>();

        for (Map.Entry<String , Post > item : getMAPpost().entrySet() )
            if (item.getValue().getIdFamily().equals(Activity_Family.idFamily)){
                LST.add(item.getValue());
            }

        if (LST.size() > 0)
            Collections.sort(LST, new Comparator<Post>() {
                @Override
                public int compare(Post object1, Post objec2) {
                    return (object1.getDate()+"").compareTo(objec2.getDate()+"");
                }
            });

        Collections.reverse(LST);

        AdapterListPosts Adapter = new AdapterListPosts(conntext , LST);
        listViewPosts.setAdapter(Adapter);
    }

    public void mLoadListViewComments(final Activity conntext, final ListView listViewComments) {

        List<Comment> LST = new ArrayList<>();

        for (Map.Entry<String , Comment > item : getMAPcomment().entrySet() )
            if (item.getValue().getIdPost().equals(Activity_Comments.post.getId())){
                LST.add(item.getValue());
            }

            if (LST.size() > 0)
            Collections.sort(LST, new Comparator<Comment>() {
                @Override
                public int compare(Comment object1, Comment objec2) {
                    return (object1.getDate()+"").compareTo(objec2.getDate()+"");
                }
            });

        AdapterListComments Adapter = new AdapterListComments(conntext , LST);
        listViewComments.setAdapter(Adapter);
    }

    public HashMap<String, User> getMAPuser() {
        return MAPuser;
    }

    public HashMap<String, Admin> getMAPadmin() {
        return MAPadmin;
    }

    public HashMap<String, Comment> getMAPcomment() {
        return MAPcomment;
    }

    public HashMap<String, Family> getMAPfamily() {
        return MAPfamily;
    }

    public HashMap<String, Like> getMAPlike() {
        return MAPlike;
    }

    public HashMap<String, com.example.discovery.ibfsn.Objects.Location> getMAPlocation() {
        return MAPlocation;
    }

    public HashMap<String, MemberFamily> getMAPmemberFamily() {
        return MAPmemberFamily;
    }

    public HashMap<String, Post> getMAPpost() {
        return MAPpost;
    }

    public List<Comment> getLSTcomment(String idPost){

        List<Comment> LST = new ArrayList<>();
        for (Map.Entry<String , Comment> item : Main.getInstance().getMAPcomment().entrySet()  ){
            if (item.getValue().getIdPost().equals(idPost))
                LST.add(item.getValue());
        }
        return LST;
    }



    public List<Like> getLSTlike(String idPost){

        List<Like> LST = new ArrayList<>();

        for (Map.Entry<String , Like> item : Main.getInstance().getMAPlike().entrySet()  ){
            if (item.getValue().getIdPostOrComment().equals(idPost))
                LST.add(item.getValue());
        }
        return LST;
    }


    public boolean mCheckAddLike(String idUser ,String idPost){

        for ( Like item :  getLSTlike(idPost) )
            if (item.getIdUser().equals(idUser))
                return true;

        return  false;
    }

    public boolean mCheckIsAdminForThisFamily() {
        for (Map.Entry<String , Admin> item : Main.getInstance().getMAPadmin().entrySet()  ){
            if (item.getValue().getIdFamily().equals(Activity_Family.idFamily)  && item.getValue().getIdUser().equals(Main.user.getId()))
                return true;
        }
        return false;
    }

    public boolean mIsExistUser(String EmailOrPhone) {

        for (Map.Entry<String , User> item : Main.getInstance().getMAPuser().entrySet()  ){
            if ( item.getValue().getEmail().equals(EmailOrPhone)
                    || (item.getValue().getPhone() != null && item.getValue().getPhone().equals(EmailOrPhone) ))
                return true;
        }
        return false;
    }

    public String mGetIdUserByEmailOrPhone(String EmailOrPhone) {

        for (Map.Entry<String , User> item : Main.getInstance().getMAPuser().entrySet()  ){
            if ( (item.getValue().getEmail() != null && item.getValue().getEmail().equals(EmailOrPhone) )
                    || (item.getValue().getPhone() != null && item.getValue().getPhone().equals(EmailOrPhone) ) )
                return item.getKey();
        }
        return null;
    }

    public boolean mCheckIsMemberInFamily(String idFamily, String idUser) {

        for (Map.Entry<String , MemberFamily> item : Main.getInstance().getMAPmemberFamily().entrySet()  ){
            if ( (  item.getValue().getIdUser() != null && item.getValue().getIdUser().equals(idUser)) && item.getValue().getIdFamily().equals(idFamily) )
                return true;
        }
        return false;
    }

    public void mDeleteMemberInFamily(String idFamily, String idUser) {

        for (Map.Entry<String , Post> item : Main.getInstance().getMAPpost().entrySet() ){
            if (item.getValue().getIdFamily().equals(idFamily)  && item.getValue().getIdUser().equals(idUser))
                mDeletePost(item.getValue().getId());
        }

        for(Map.Entry<String , Comment> item : Main.getInstance().getMAPcomment().entrySet() ){

            if ( item.getValue().getIdUser().equals(idUser)
                    &&  Main.getInstance().getMAPpost().get( item.getValue().getIdPost()).getIdFamily().equals(idFamily) ){

                mDeleteComment(item.getValue().getId());
            }
        }

        for(Map.Entry<String , Like> item : Main.getInstance().getMAPlike().entrySet() ){

            if ( item.getValue().getIdUser().equals(idUser)
                    &&  Main.getInstance().getMAPpost().get( item.getValue().getIdPostOrComment() ).getIdFamily().equals(idFamily) ){

                mDeleteLike(item.getValue().getId());
            }
        }

        for (Map.Entry<String , MemberFamily> item : Main.getInstance().getMAPmemberFamily().entrySet()  ){
            if ( item.getValue().getIdUser() != null && item.getValue().getIdUser().equals(idUser) && item.getValue().getIdFamily().equals(idFamily)){
                AppRefDB.RefMembersFamily.child(item.getValue().getId()).removeValue();
                break;
            }
        }


    }

    public int mGetNumberOfMembers(String idFamily){

        int num=0;
        for (Map.Entry<String , MemberFamily > item : Main.getInstance().getMAPmemberFamily().entrySet() )
            if (item.getValue().getIdFamily().equals(idFamily))
                num++;

        return num;
    }

    public int mGetNumberOfPost(String familyId) {

        int num=0;
        for (Map.Entry<String , Post > item : Main.getInstance().getMAPpost().entrySet() )
            if (item.getValue().getIdFamily().equals(familyId))
                num++;

        return num;
    }

    public int mGetNumberFamilyForUser(String idUser){

        int num=0;
        for (Map.Entry<String , MemberFamily > item : getMAPmemberFamily().entrySet() )
            if (item.getValue().getIdUser().equals(idUser)){
              num++;
            }

            return num;
    }

    public void mDeletePost(String idPost){

        for (Comment item : Main.getInstance().getLSTcomment(idPost) ){
            Main.getInstance().mDeleteComment(item.getId());
        }

        for (Like item :Main.getInstance().getLSTlike(idPost) ){
            Main.getInstance().mDeleteLike(item.getId());
        }

        AppRefDB.RefPosts.child(idPost).removeValue();
    }

    public void mDeleteComment(String idComment){
        AppRefDB.RefComments.child(idComment).removeValue();
    }

    public void mDeleteLike(String idPostOrComment){
        AppRefDB.RefLikes.child(idPostOrComment).removeValue();
    }


}
