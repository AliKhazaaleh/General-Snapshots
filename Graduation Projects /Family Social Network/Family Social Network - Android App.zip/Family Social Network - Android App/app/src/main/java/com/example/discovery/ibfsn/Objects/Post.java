package com.example.discovery.ibfsn.Objects;

import com.example.discovery.ibfsn.Others.AppSettings;
import com.example.discovery.ibfsn.Others.Main;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;


public class Post {

    private String id;
    private String idUser;
    private String text;
    private String idFamily;
    private String privacy;
    private String linkPhoto;
    private double locLat;
    private double locLon;
    private long date;
    private List<String>LSTuser = new ArrayList<>();

    public Post() {
    }

    public Post(String id, String idUser, String text,String idFamily, String privacy , String linkPhoto) {
        this.id = id;
        this.idUser = idUser;
        this.text = text;
        this.idFamily = idFamily;
        this.privacy = privacy;
        this.linkPhoto = linkPhoto;
        this.date = AppSettings.CurrentTimeMillis();
    }

    public Post(String id, String idUser, String text,String idFamily, String privacy, String linkPhoto, double locLat,double locLon) {
        this.id = id;
        this.idUser = idUser;
        this.text = text;
        this.idFamily = idFamily;
        this.privacy = privacy;
        this.linkPhoto = linkPhoto;
        this.locLat = locLat;
        this.locLon = locLon;
        this.date = AppSettings.CurrentTimeMillis();
        this.LSTuser = LSTuser;
    }

    public Post(String id, String idUser, String text,String idFamily, String privacy, String linkPhoto, double locLat,double locLon, long date , List<String> LSTuser) {
        this.id = id;
        this.idUser = idUser;
        this.text = text;
        this.idFamily = idFamily;
        this.privacy = privacy;
        this.linkPhoto = linkPhoto;
        this.locLat = locLat;
        this.locLon = locLon;
        this.date = date;
        this.LSTuser = LSTuser;
    }

    public Post(String id, String idUser, String text,String idFamily, String privacy, String linkPhoto, double locLat,double locLon,  List<String> LSTuser) {
        this.id = id;
        this.idUser = idUser;
        this.text = text;
        this.idFamily = idFamily;
        this.privacy = privacy;
        this.linkPhoto = linkPhoto;
        this.locLat = locLat;
        this.locLon = locLon;
        this.date = AppSettings.CurrentTimeMillis();
        this.LSTuser = LSTuser;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getIdUser() {
        return idUser;
    }

    public void setIdUser(String idUser) {
        this.idUser = idUser;
    }

    public String getText() {
        return text;
    }

    public void setText(String text) {
        this.text = text;
    }

    public long getDate() {
        return date;
    }

    public void setDate(long date) {
        this.date = date;
    }

    public String getIdFamily() {
        return idFamily;
    }

    public void setIdFamily(String idFamily) {
        this.idFamily = idFamily;
    }

    public String getPrivacy() {
        return privacy;
    }

    public void setPrivacy(String privacy) {
        this.privacy = privacy;
    }

    public String getLinkPhoto() {
        return linkPhoto;
    }

    public void setLinkPhoto(String linkPhoto) {
        this.linkPhoto = linkPhoto;
    }

    public double getLocLat() {
        return locLat;
    }

    public void setLocLat(double locLat) {
        this.locLat = locLat;
    }

    public double getLocLon() {
        return locLon;
    }

    public void setLocLon(double locLon) {
        this.locLon = locLon;
    }

    public List<String> getLSTuser() {
        return LSTuser;
    }
/*
    public User getUser(){
        return Main.getInstance().getMAPuser().get(idUser);
    }

    public Family getFamily(){
        return Main.getInstance().getMAPfamily().get(idFamily);
    }




*/

    public static String PALL = "ALL";
    public static String PSOME ="SOME";

}
