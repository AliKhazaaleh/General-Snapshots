package com.example.discovery.ibfsn.Fragments;

import android.app.AlertDialog;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.design.widget.FloatingActionButton;
import android.support.v4.app.Fragment;
import android.text.Layout;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.accessibility.AccessibilityManager;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.MultiAutoCompleteTextView;
import android.widget.Spinner;
import android.widget.Toast;

import com.example.discovery.ibfsn.Activites.Activity_Family;
import com.example.discovery.ibfsn.Adapter.AdapterListMembers;
import com.example.discovery.ibfsn.Objects.Admin;
import com.example.discovery.ibfsn.Objects.MemberFamily;
import com.example.discovery.ibfsn.Objects.Post;
import com.example.discovery.ibfsn.Others.AppRefDB;
import com.example.discovery.ibfsn.Others.AppSettings;
import com.example.discovery.ibfsn.Others.Main;
import com.example.discovery.ibfsn.R;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import es.dmoral.toasty.Toasty;

/**
 * Created by Discovery on 26/04/2018.
 */

public class Fragment_FamilyMembers extends Fragment {

    View rootView;
    ListView listViewMembers;
    View viewLayoutAddMember;
    private Spinner spinnerAdjective;
    List<String> LSTspinnerAdjective;

    public static Fragment_FamilyMembers newInstance() {
        Fragment_FamilyMembers fragment = new Fragment_FamilyMembers();
        return fragment;
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, Bundle savedInstanceState) {

        rootView = inflater.inflate(R.layout.fragment_family_members, container, false);
        mLoadObjects();
        mLoadUI();

        Main.getInstance().mLoadListViewMembers(getActivity() , listViewMembers);

        return  rootView;
    }


    private void mLoadObjects() {

        LSTspinnerAdjective = new ArrayList<>();
        LSTspinnerAdjective.add(MemberFamily.FATHER);
        LSTspinnerAdjective.add(MemberFamily.MOTHER);
        LSTspinnerAdjective.add(MemberFamily.SON);
        LSTspinnerAdjective.add(MemberFamily.GRANDSON);
        LSTspinnerAdjective.add(MemberFamily.GRANDFATHER);
        LSTspinnerAdjective.add(MemberFamily.GRANDMOTHER);

    }

    private void mLoadUI() {

        listViewMembers = (ListView)rootView.findViewById(R.id.listViewMembers);
        spinnerAdjective = (Spinner)rootView.findViewById(R.id.spinnerAdjective);
        viewLayoutAddMember = rootView.findViewById(R.id.layoutAddMember);


        if (!Main.getInstance().mCheckIsAdminForThisFamily()){
            ((FloatingActionButton)rootView.findViewById(R.id.floatingActionButtonAddMember)).setVisibility(View.GONE);
        }

        ArrayAdapter<String> adapter = new ArrayAdapter<String>(getContext(),
                android.R.layout.simple_spinner_dropdown_item , LSTspinnerAdjective);
        spinnerAdjective.setAdapter(adapter);



        ((FloatingActionButton)rootView.findViewById(R.id.floatingActionButtonAddMember)).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                viewLayoutAddMember.setVisibility(View.VISIBLE);
            }
        });

        ((Button)rootView.findViewById(R.id.buttonAddMember)).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if (((EditText) rootView.findViewById(R.id.editTextEmailOrPhoneForAdd)).getText().toString().isEmpty()) {
                    Toasty.warning( getContext(), "fill Email or Phone", Toast.LENGTH_SHORT, true).show();
                    return;
                }

                if (Main.getInstance().mIsExistUser(((EditText) rootView.findViewById(R.id.editTextEmailOrPhoneForAdd)).getText().toString())) {

                    if (!AppSettings.mIsNetworkAvailable(getActivity(), view) )
                        return;

                    if (Main.getInstance().mCheckIsMemberInFamily(Activity_Family.idFamily ,Main.getInstance().mGetIdUserByEmailOrPhone(((EditText)rootView.findViewById(R.id.editTextEmailOrPhoneForAdd)).getText().toString())) ){
                        Toasty.warning(getContext(), "already member in family", Toast.LENGTH_SHORT, true).show();
                        return;
                    }

                    Admin.mAddMemberFamily(Activity_Family.idFamily
                            , Main.getInstance().mGetIdUserByEmailOrPhone(((EditText) rootView.findViewById(R.id.editTextEmailOrPhoneForAdd)).getText().toString())
                            , spinnerAdjective.getSelectedItem().toString());
                Toasty.success(getContext(), "Success", Toast.LENGTH_SHORT, true).show();

                    Main.getInstance().mLoadListViewMembers(getActivity() , listViewMembers);
                    viewLayoutAddMember.setVisibility(View.GONE);
            }else{
                    Toasty.warning( getContext(), "Not Exist User", Toast.LENGTH_SHORT, true).show();
                    return;
                }
            }
        });

        ((Button)rootView.findViewById(R.id.buttonCloseLayoutAddMember)).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                viewLayoutAddMember.setVisibility(View.GONE);
            }
        });

        ((Button)rootView.findViewById(R.id.buttonDeleteMember)).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if (((EditText) rootView.findViewById(R.id.editTextEmailOrPhoneForAdd)).getText().toString().isEmpty()) {
                    Toasty.warning( getContext(), "fill Email or Phone", Toast.LENGTH_SHORT, true).show();
                    return;
                }

                String idUser;
                if (Main.getInstance().mIsExistUser(((EditText) rootView.findViewById(R.id.editTextEmailOrPhoneForAdd)).getText().toString())) {
                    idUser = Main.getInstance().mGetIdUserByEmailOrPhone( ((EditText) rootView.findViewById(R.id.editTextEmailOrPhoneForAdd)).getText().toString());

                    if ( idUser.equals(Main.user.getId()) ){
                        Toasty.warning( getContext(), "Not Can delete your self (Admin) but Can Delete Full Family", Toast.LENGTH_SHORT, true).show();
                        return;
                    }
                }

                if ( Main.getInstance().mIsExistUser(((EditText) rootView.findViewById(R.id.editTextEmailOrPhoneForAdd)).getText().toString())) {

                    if (Main.getInstance().mCheckIsMemberInFamily(Activity_Family.idFamily ,  Main.getInstance().mGetIdUserByEmailOrPhone(  ((EditText) rootView.findViewById(R.id.editTextEmailOrPhoneForAdd)).getText().toString()))){
                        Main.getInstance().mDeleteMemberInFamily(Activity_Family.idFamily , Main.getInstance().mGetIdUserByEmailOrPhone( ((EditText) rootView.findViewById(R.id.editTextEmailOrPhoneForAdd)).getText().toString()) );
                        Toasty.success(getContext(), "Success Deleted", Toast.LENGTH_SHORT, true).show();
                    }
                    else
                        Toasty.warning( getContext(), "Not exist This Member in Family", Toast.LENGTH_SHORT, true).show();
                }
                else
                    Toasty.warning( getContext(), "Not exist This user", Toast.LENGTH_SHORT, true).show();
                // Success Deleted

            }
        });
    }
}