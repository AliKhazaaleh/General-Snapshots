package com.example.discovery.ibfsn.Activites;

import android.content.ContentResolver;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.webkit.MimeTypeMap;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.Spinner;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;
import android.os.Handler;

import com.example.discovery.ibfsn.Others.AppRefDB;
import com.example.discovery.ibfsn.Others.AppSettings;
import com.example.discovery.ibfsn.Others.Main;
import com.example.discovery.ibfsn.R;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.OnProgressListener;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.StorageTask;
import com.google.firebase.storage.UploadTask;
import com.squareup.picasso.Picasso;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.InputStream;

import es.dmoral.toasty.Toasty;

public class Activity_CreatePost extends AppCompatActivity {


    private static final int PICK_IMAGE_REQUEST = 1;

    private Switch switchLocation;
    private EditText editTextTextPost;
    private ImageView imageViewPhotoPost;
    private ProgressBar progress_bar;
    private Button buttonCreatePost;
    private Uri mImageUri;
    private StorageTask mUploadTask;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_create_post);

        mLoadObjects();
        mLoadUI();
        mLoadActions();
    }

    private void mLoadObjects() {

    }

    private void mLoadUI() {

        switchLocation = (Switch)findViewById(R.id.switchLocation);
        editTextTextPost = (EditText) findViewById(R.id.editTextTextPost);
        imageViewPhotoPost = (ImageView) findViewById(R.id.imageViewPhotoPost);
        progress_bar = (ProgressBar) findViewById(R.id.progress_bar);
        buttonCreatePost = (Button) findViewById(R.id.buttonCreatePost);
    }


    private void mLoadActions() {

        imageViewPhotoPost.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    openFileChooser();
                }
            });

        buttonCreatePost.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {

                    if (!AppSettings.mIsNetworkAvailable(Activity_CreatePost.this , view)){
                        return;
                    }

                    /*
                    if (editTextTextPost.getText().toString().length() <= 5 ){
                        Toasty.warning( getBaseContext(), "text Post must more than 5 char", Toast.LENGTH_SHORT, true).show();
                        return;
                    }*/

                    if (mUploadTask != null && mUploadTask.isInProgress()) {
                        Toasty.warning( getBaseContext(), "Upload in progress", Toast.LENGTH_SHORT, true).show();
                    } else {
                        uploadFile();
                    }
                }
            });
    }


    private void openFileChooser() {
        Intent intent = new Intent();
        intent.setType("image/*");
        intent.setAction(Intent.ACTION_GET_CONTENT);
        startActivityForResult(intent, PICK_IMAGE_REQUEST);
    }



    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        try {
            if (requestCode == PICK_IMAGE_REQUEST && resultCode == RESULT_OK
                    && data != null && data.getData() != null) {
                mImageUri = data.getData();
                final Uri imageUri = data.getData();
                final InputStream imageStream;
                imageStream = getContentResolver().openInputStream(imageUri);

                final Bitmap selectedImage = BitmapFactory.decodeStream(imageStream);
                imageViewPhotoPost.setImageBitmap(selectedImage);
            }

        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
    }

    private String getFileExtension(Uri uri) {
        ContentResolver cR = getContentResolver();
        MimeTypeMap mime = MimeTypeMap.getSingleton();
        return mime.getExtensionFromMimeType(cR.getType(uri));
    }

    private void uploadFile() {

        if (mImageUri != null) {
            StorageReference fileReference = AppRefDB.mStorageRef.child(System.currentTimeMillis()
                    + "." + getFileExtension(mImageUri));

            mUploadTask = fileReference.putFile(mImageUri)
                    .addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
                        @Override
                        public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {
                            Handler handler = new Handler();
                            handler.postDelayed(new Runnable() {
                                @Override
                                public void run() {
                                    progress_bar.setProgress(0);
                                }
                            }, 500);

                            Main.user.mCreatePost(editTextTextPost.getText().toString() , taskSnapshot.getDownloadUrl() != null ? taskSnapshot.getDownloadUrl().toString() : "" ,switchLocation.isChecked() );
                            Toasty.success( getBaseContext(), "Upload successful", Toast.LENGTH_SHORT, true).show();
                            buttonCreatePost.setEnabled(false);
                            Intent intent = new Intent(Activity_CreatePost.this , Activity_Family.class);
                            startActivity(intent);
                        }
                    })
                    .addOnFailureListener(new OnFailureListener() {
                        @Override
                        public void onFailure(@NonNull Exception e) {
                            Toasty.error( getBaseContext(), e.getMessage(), Toast.LENGTH_SHORT, true).show();
                        }
                    })
                    .addOnProgressListener(new OnProgressListener<UploadTask.TaskSnapshot>() {
                        @Override
                        public void onProgress(UploadTask.TaskSnapshot taskSnapshot) {
                            double progress = (100.0 * taskSnapshot.getBytesTransferred() / taskSnapshot.getTotalByteCount());
                            progress_bar.setProgress((int) progress);
                        }
                    });
        } else {
            Toasty.warning( getBaseContext(), "No file selected", Toast.LENGTH_SHORT, true).show();
           /* buttonCreatePost.setEnabled(false);
            Main.user.mCreatePost(editTextTextPost.getText().toString() , "" ,switchLocation.isChecked() );
            Toast.makeText(Activity_CreatePost.this, "Upload successful", Toast.LENGTH_LONG).show();
        */
        }
    }


}
