package com.example.discovery.ibfsn.Objects;


import com.example.discovery.ibfsn.Others.AppRefDB;
import com.example.discovery.ibfsn.Others.Main;

public class Admin {

    private String id;
    private String idFamily;
    private String idUser;

    public Admin() {
    }

    public Admin(String id, String idFamily, String idUser) {
        this.id = id;
        this.idFamily = idFamily;
        this.idUser = idUser;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getIdFamily() {
        return idFamily;
    }

    public void setIdFamily(String idFamily) {
        this.idFamily = idFamily;
    }

    public String getIdUser() {
        return idUser;
    }

    public void setIdUser(String idUser) {
        this.idUser = idUser;
    }

    /*
    public User getUser(){
        return Main.getInstance().getMAPuser().get(idUser);
    }

    public Family getFamily() {
        return Main.getInstance().getMAPfamily().get(idFamily);
    }
*/

    // Add new Member
    // mAddMemberFamily from class Admin
    public static void mAddMemberFamily( String idFamily , String idUser ,String adjective){

        String idMemberFamily = AppRefDB.RefMembersFamily.push().getKey();
        MemberFamily memberFamily = new MemberFamily(idMemberFamily, idUser ,idFamily ,adjective);

        Main.getInstance().getMAPmemberFamily().put(idMemberFamily , memberFamily);
        AppRefDB.RefMembersFamily.child(idMemberFamily).setValue(memberFamily);
    }


}
