package com.example.discovery.ibfsn.Others;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.StorageTask;


public class AppRefDB {

    private static FirebaseDatabase DB = FirebaseDatabase.getInstance();
    public static DatabaseReference RefUsers = DB.getReference("Users");
    public static DatabaseReference RefAdmins = DB.getReference("Admins");
    public static DatabaseReference RefFamilies = DB.getReference("Families");
    public static DatabaseReference RefPosts = DB.getReference("Posts");
    public static DatabaseReference RefComments = DB.getReference("Comments");
    public static DatabaseReference RefLikes = DB.getReference("Likes");
    public static DatabaseReference RefMembersFamily = DB.getReference("MembersFamily");
    public static DatabaseReference RefLocations = DB.getReference("Locations");
    public static StorageReference mStorageRef = FirebaseStorage.getInstance().getReference("img");


    private AppRefDB() {
    }

}
