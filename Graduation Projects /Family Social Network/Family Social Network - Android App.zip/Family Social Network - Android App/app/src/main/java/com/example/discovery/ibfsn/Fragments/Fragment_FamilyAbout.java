package com.example.discovery.ibfsn.Fragments;

import android.app.AlertDialog;
import android.os.Bundle;
import android.provider.ContactsContract;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.example.discovery.ibfsn.Activites.Activity_Family;
import com.example.discovery.ibfsn.Objects.Family;
import com.example.discovery.ibfsn.Others.Main;
import com.example.discovery.ibfsn.R;
import com.squareup.picasso.Picasso;

import java.util.Date;

import de.hdodenhof.circleimageview.CircleImageView;
import es.dmoral.toasty.Toasty;

/**
 * Created by Discovery on 26/04/2018.
 */

public class Fragment_FamilyAbout extends Fragment {

    View rootView;
    CircleImageView imageViewPhotoFamily;
    Family family;

    public static Fragment_FamilyAbout newInstance() {
        Fragment_FamilyAbout fragment = new Fragment_FamilyAbout();
        return fragment;
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, Bundle savedInstanceState) {

        rootView = inflater.inflate(R.layout.fragment_family_about, container, false);
        mLoadObjects();
        mLoadUI();
        mLoadActions();

        /*
        AdapterListMyOfferBook Adapter = new AdapterListMyOfferBook(getActivity() ,  Main.user.getOfferBook());
        listViewOfferBookInProcess.setAdapter(Adapter);
*/
        return  rootView;
    }


    private void mLoadObjects() {
        family = Main.getInstance().getMAPfamily().get(Activity_Family.idFamily);
    }

    private void mLoadUI() {

        imageViewPhotoFamily = (CircleImageView)rootView.findViewById(R.id.imageViewPhotoFamily);

        if ( family.getLinkPhoto() == null ||  family.getLinkPhoto().equals("") ) {
            ((CircleImageView)rootView.findViewById(R.id.imageViewPhotoFamily)).setImageResource(R.mipmap.logo_family);
        } else {
            Picasso.get().load(family.getLinkPhoto()).into((CircleImageView)rootView.findViewById(R.id.imageViewPhotoFamily));
        }

        ((TextView)rootView.findViewById(R.id.textViewName)).setText(family.getName());



        ((TextView)rootView.findViewById(R.id.textViewNOfMember)).setText(Main.getInstance().mGetNumberOfMembers(family.getId())+"");
        ((TextView)rootView.findViewById(R.id.textViewNOfPost)).setText(Main.getInstance().mGetNumberOfPost(family.getId())+"");
    }

    private void mLoadActions() {

        ((TextView)rootView.findViewById(R.id.textViewDOB)).setOnClickListener(new View.OnClickListener() {
        @Override
        public void onClick(View view) {
            Date d = new Date(family.getDate());
            Toasty.info(getActivity() , d.toString() , Toast.LENGTH_SHORT, true).show();
        }
        });


        ((CircleImageView)rootView.findViewById(R.id.imageViewPhotoFamily)).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                AlertDialog.Builder dialogBuilder = new AlertDialog.Builder(getContext());
                final ImageView imageViewPhoto = new ImageView(getContext());

                if (family.getLinkPhoto() != null)
                    Picasso.get().load(family.getLinkPhoto()).into(imageViewPhoto);

                dialogBuilder.setView(imageViewPhoto);

                AlertDialog alertDialog = dialogBuilder.create();
                alertDialog.show();
            }
        });
    }
}