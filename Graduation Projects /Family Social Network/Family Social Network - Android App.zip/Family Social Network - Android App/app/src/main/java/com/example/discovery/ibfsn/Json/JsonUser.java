package com.example.discovery.ibfsn.Json;

import com.example.discovery.ibfsn.Objects.User;

/**
 * Created by Discovery on 18/04/2018.
 */

public class JsonUser {

    public String id;
    public String name;
    public String email;
    public String phone;
    public String status;
    public String linkPhoto;
    public long lastLogin;
    public String dateOfBirth;

    public User ConvertToObject(){
        User user = new User(id,name,email,phone,status,linkPhoto,lastLogin,dateOfBirth);
        return user;
    }
}
